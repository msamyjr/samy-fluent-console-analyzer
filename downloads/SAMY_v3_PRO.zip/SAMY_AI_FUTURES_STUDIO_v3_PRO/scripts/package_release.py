"""Package source, docs, tests and explicit evidence; exclude all runtime accounts."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',default='dist/SAMY_AI_FUTURES_STUDIO_v3_PRO.zip')
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    output=Path(args.output).resolve()
    output.parent.mkdir(parents=True,exist_ok=True)
    selected=[]
    for entry in ('samy','tests','config','docs','examples','scripts','README.md','requirements.txt',
                  'requirements-browser.txt','start_windows.bat','install_windows.bat','index.html','.python-version','.gitignore'):
        base=root/entry
        if not base.exists():
            continue
        for path in (sorted(base.rglob('*')) if base.is_dir() else [base]):
            if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts and path.suffix not in ('.pyc','.sqlite','.log'):
                selected.append(path)
    # The single explicitly allowed test log contains no account data.
    test_log=root/'docs/evidence/unittest.log'
    if test_log.exists():
        selected.append(test_log)
    selected=sorted(set(selected))
    manifest={str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in selected}
    prefix='SAMY_AI_FUTURES_STUDIO_v3_PRO/'
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED) as archive:
        for p in selected:
            archive.write(p,prefix+p.relative_to(root).as_posix())
        archive.writestr(prefix+'MANIFEST.sha256.json',json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('ZIP integrity failed')
    checksum=hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_suffix('.zip.sha256').write_text(checksum+'  '+output.name+'\n')
    print(json.dumps(dict(archive=str(output),sha256=checksum,files=len(manifest),bytes=output.stat().st_size),indent=2))


if __name__=='__main__':
    main()
