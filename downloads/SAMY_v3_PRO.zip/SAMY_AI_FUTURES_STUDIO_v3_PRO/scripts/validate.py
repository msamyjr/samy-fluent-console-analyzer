"""Run the actual unittest suite and retain machine-readable outcomes."""
import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import platform
import sys
import unittest


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output-dir',default='reports/validation')
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    sys.path.insert(0,str(root))
    output=Path(args.output_dir)
    output.mkdir(parents=True,exist_ok=True)
    suite=unittest.defaultTestLoader.discover(str(root/'tests'))
    started=datetime.now(timezone.utc)
    with (output/'unittest.log').open('w',encoding='utf-8') as stream:
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    report=dict(started=started.isoformat(),finished=datetime.now(timezone.utc).isoformat(),python=sys.version,
                platform=platform.platform(),executed=result.testsRun,
                passed=result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped)-len(result.expectedFailures)-len(result.unexpectedSuccesses),
                failed=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),
                expected_failures=len(result.expectedFailures),unexpected_successes=len(result.unexpectedSuccesses),
                failures=[dict(test=str(t),traceback=trace) for t,trace in result.failures+result.errors],
                external_checks_not_executed=['Windows 10/11 execution of repaired 3.0.1','Live Binance Futures integration (network denied)'])
    (output/'test-results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))
    return 0 if result.wasSuccessful() else 1


if __name__=='__main__':
    sys.exit(main())
