"""Optional real-browser smoke check. Use a disposable demo account: this latches stop."""
import argparse
import json
from pathlib import Path
from datetime import datetime,timezone
from playwright.sync_api import sync_playwright


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--browser-executable')
    parser.add_argument('--output-dir',default='reports/browser')
    args=parser.parse_args()
    output=Path(args.output_dir)
    output.mkdir(parents=True,exist_ok=True)
    errors=[]
    with sync_playwright() as p:
        options=dict(headless=True)
        if args.browser_executable:
            options.update(executable_path=args.browser_executable,args=['--no-sandbox'])
        browser=p.chromium.launch(**options)
        page=browser.new_page(viewport=dict(width=1440,height=1050))
        page.on('pageerror',lambda e:errors.append(str(e)))
        url=f'http://127.0.0.1:{args.port}'
        page.goto(url,wait_until='networkidle')
        page.wait_for_function("document.querySelector('#source').textContent==='SYNTHETIC DEMO'")
        assert page.locator('#stats .stat').count()==4
        assert page.locator('#watchlist tbody tr').count()==3
        page.screenshot(path=str(output/'dashboard-desktop.png'),full_page=True)
        for tab in ('scanner','positions','research','backtests','health','overview'):
            page.locator(f'nav button[data-page="{tab}"]').click()
            assert page.locator(f'#{tab}').is_visible()
        page.locator('nav button[data-page="scanner"]').click()
        page.locator('#search').fill('DEMOA')
        assert page.locator('#scanner-table tbody tr').count()==1
        page.locator('#scanner-table .symbol').first.click()
        assert 'DEMOAUSDT' in page.locator('#market-detail').inner_text()
        page.locator('nav button[data-page="backtests"]').click()
        page.locator('#backtest-command button').click()
        assert 'python -m samy backtest' in page.locator('#command').inner_text()
        page.on('dialog',lambda d:d.accept())
        page.locator('#kill').click()
        page.wait_for_function("document.querySelector('#toast').textContent.includes('STOP LATCHED')")
        assert page.request.get(url+'/api/state').json()['account']['killed']
        page.set_viewport_size(dict(width=390,height=844))
        page.locator('nav button[data-page="overview"]').click()
        page.screenshot(path=str(output/'dashboard-mobile.png'),full_page=True)
        assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth')
        assert not errors,errors
        report=dict(executed=datetime.now(timezone.utc).isoformat(),browser=browser.version,
                    passed=['desktop render','mobile render without viewport overflow','six navigation tabs',
                            'market filter','market detail','backtest command builder','session-token emergency stop'],
                    javascript_errors=errors,source='synthetic-demo')
        browser.close()
    (output/'browser-results.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
