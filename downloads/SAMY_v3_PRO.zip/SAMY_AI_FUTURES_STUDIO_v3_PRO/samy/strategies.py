"""Research candidates, never implicitly approved for autonomous execution."""
from .models import Signal
from .config import INTERVALS
from .indicators import features, regime

STRATEGIES = {
 'trend': 'EMA alignment with RSI confirmation in directional regimes',
 'momentum': 'Ten-bar ROC above ATR-normalized threshold in trend regime',
 'breakout': 'Close beyond prior 20-bar support/resistance',
 'retest': 'Previous close broke prior range; current low/high retests and closes beyond it',
 'mean_reversion': 'Two-sigma extension and RSI extreme in sideways regime',
 'volatility': 'Bollinger expansion beyond Keltner channel with directional ROC',
 'alignment': 'All available requested timeframes agree on EMA direction',
 'volume_breakout': 'Range breakout with relative volume above 1.5',
 'funding': 'Trend confirmation with funding favorable to position (not arbitrage)',
 'adaptive': 'Trend in directional regime, mean reversion in sideways regime',
}


def generate(snapshot, strategy='adaptive'):
    if strategy not in STRATEGIES:
        raise ValueError('Unknown strategy')
    candles = snapshot.candles[snapshot.interval]
    f = features(candles)
    r = regime(f)
    if r in ('UNSTABLE', 'LOW VOLATILITY') or f['atr'] <= 0:
        return None
    price = snapshot.price
    trend = 1 if f['ema12'] > f['ema26'] else -1
    side = 0
    breakout = 1 if f['price'] > f['resistance'] else -1 if f['price'] < f['support'] else 0
    trend_ok = r in ('BULL TREND', 'BEAR TREND') and 35 < f['rsi'] < 75
    reverting = -1 if f['zscore'] > 2 and f['rsi'] > 70 else 1 if f['zscore'] < -2 and f['rsi'] < 30 else 0
    if strategy == 'trend' and trend_ok:
        side = trend
    elif strategy == 'momentum' and trend_ok and abs(f['roc']) > 2*f['atr']/price:
        side = 1 if f['roc']>0 else -1
    elif strategy == 'breakout':
        side = breakout
    elif strategy == 'retest':
        boundary_hi = max(x.high for x in candles[-22:-2])
        boundary_lo = min(x.low for x in candles[-22:-2])
        if candles[-2].close > boundary_hi and candles[-1].low <= boundary_hi < candles[-1].close:
            side = 1
        elif candles[-2].close < boundary_lo and candles[-1].high >= boundary_lo > candles[-1].close:
            side = -1
    elif strategy == 'mean_reversion' and r == 'SIDEWAYS':
        side = reverting
    elif strategy == 'volatility' and f['bb_upper'] > f['keltner_upper'] and abs(f['roc']) > f['atr']/price:
        side = 1 if f['roc']>0 else -1
    elif strategy == 'alignment' and len(snapshot.candles) >= 3 and trend_ok:
        directions = [1 if features(c)['ema12'] > features(c)['ema26'] else -1 for c in snapshot.candles.values()]
        if all(x == trend for x in directions):
            side = trend
    elif strategy == 'volume_breakout' and f['relative_volume'] > 1.5:
        side = breakout
    elif strategy == 'funding' and trend_ok and snapshot.funding * trend < -0.0001:
        side = trend
    elif strategy == 'adaptive':
        side = trend if trend_ok else reverting if r == 'SIDEWAYS' else 0
    if not side:
        return None
    distance = max(2*f['atr'], price*0.003)
    if price - distance <= 0:
        return None
    score = min(100, abs(f['ema12']-f['ema26'])/f['atr']*15 + min(f['relative_volume'],3)*10)
    return Signal(snapshot.contract.symbol, side, strategy, price-side*distance,
                  price+side*2*distance, score, STRATEGIES[strategy] + '; heuristic score, not a probability',
                  r, f['volatility'], candles[-1].time+INTERVALS[snapshot.interval])
