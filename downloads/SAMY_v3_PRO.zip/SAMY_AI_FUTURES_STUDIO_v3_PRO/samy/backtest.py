"""Chronological portfolio simulation: previous closed-bar signal, next-open fills."""
from bisect import bisect_left
from dataclasses import asdict
import math
from statistics import mean,pstdev
import tempfile
from pathlib import Path
from .models import Candle,Contract,Snapshot
from .config import INTERVALS
from .indicators import features
from .strategies import generate,STRATEGIES
from .store import Store
from .broker import PaperBroker
from .dataset import validate_dataset,fingerprint

HISTORICAL_SPREAD_BPS = 2.0
EXECUTION_MODEL = 'reference OHLC + executable-side half-spread on entry and exit'


def metrics(trades,curve,initial,interval_ms=60000):
    pnl=[x['net_pnl'] for x in trades]
    wins=[x for x in pnl if x>0]
    losses=[x for x in pnl if x<0]
    peak=initial
    dd=0.0
    values=[initial]+[x[1] for x in curve]
    for value in values:
        peak=max(peak,value)
        dd=max(dd,1-value/peak)
    returns=[b/a-1 for a,b in zip(values,values[1:]) if a>0]
    # Ratios are per-observation, not spuriously annualized from event counts.
    deviation=pstdev(returns) if len(returns)>1 else 0
    downside=math.sqrt(mean(min(0,r)**2 for r in returns)) if returns else 0
    total=values[-1]/initial-1
    return dict(trades=len(pnl),net_pnl=values[-1]-initial,return_on_equity=total,max_drawdown=dd,
      profit_factor=sum(wins)/abs(sum(losses)) if losses else None,win_rate=len(wins)/len(pnl) if pnl else None,
      average_win=mean(wins) if wins else None,average_loss=mean(losses) if losses else None,
      expectancy=mean(pnl) if pnl else None,sharpe_per_bar=mean(returns)/deviation if deviation else None,
      sortino_per_bar=mean(returns)/downside if downside else None,return_to_drawdown=total/dd if dd else None,
      fees=sum(t['entry_fee']+t['exit_fee'] for t in trades),funding=sum(t['funding'] for t in trades),
      turnover=sum(t['qty']*(t['entry']+t['exit']) for t in trades),
      worst_trade=min(pnl) if pnl else None,insurance_deficit=sum(t['insurance_deficit'] for t in trades))


def run_backtest(data,config,strategy='adaptive',start=None,end=None):
    validate_dataset(data)
    if strategy not in STRATEGIES:
        raise ValueError('Unknown strategy')
    interval=INTERVALS[data['interval']]
    series={s:[Candle(**x) for x in item['candles']] for s,item in data['symbols'].items()}
    timeline=sorted(set(c.time for rows in series.values() for c in rows))
    start=start if start is not None else timeline[0]+config.min_history*interval
    end=end if end is not None else timeline[-1]+interval
    timeline=[t for t in timeline if start<=t<end]
    if not timeline:
        raise ValueError('Selected historical period is empty')
    indices={s:{c.time:i for i,c in enumerate(rows)} for s,rows in series.items()}
    rejected={}
    curves=[]
    exposure=0
    active_funding={s:list(item.get('funding',[])) for s,item in data['symbols'].items()}
    with tempfile.TemporaryDirectory() as temp:
        store=Store(Path(temp)/'backtest.sqlite')
        broker=PaperBroker(config,store,exit_half_spread_bps=HISTORICAL_SPREAD_BPS/2)
        for t in timeline:
            # Settlement events at or before the next opening price, only for existing holdings.
            for s,events in active_funding.items():
                while events and events[0]['time']<=t:
                    f=events.pop(0)
                    broker.funding(s,f['rate'],f['mark'],f['time'],t)
            candidates=[]
            histories={}
            for s,rows in series.items():
                i=indices[s].get(t)
                if i is None or i<config.min_history:
                    continue
                history=rows[max(0,i-config.min_history):i]
                histories[s]=features(history)['returns']
                item=data['symbols'][s]
                last_funding=next((x['rate'] for x in reversed(item.get('funding',[])) if x['time']<=t),0)
                price=rows[i].open
                spread=HISTORICAL_SPREAD_BPS/10000  # Declared assumption, not measured historical depth.
                snap=Snapshot(Contract(**item['contract']),t,price,price*(1-spread/2),price*(1+spread/2),
                              100_000_000,0,last_funding,1, {data['interval']:history},histories[s],source='historical',interval=data['interval'])
                signal=generate(snap,strategy)
                if signal:
                    candidates.append((signal.score,snap,signal))
            for _,snap,signal in sorted(candidates,key=lambda x:(-x[0],x[1].contract.symbol)):
                decision=broker.open(snap,signal,t,histories)
                if not decision['approved']:
                    reason=decision['reason']
                    rejected[reason]=rejected.get(reason,0)+1
            settlements=[]
            for s,events in active_funding.items():
                while events and events[0]['time']<t+interval:
                    settlements.append((events.pop(0),s))
            for f,s in sorted(settlements,key=lambda x:x[0]['time']):
                broker.funding(s,f['rate'],f['mark'],f['time'],f['time'])
            for s,rows in series.items():
                i=indices[s].get(t)
                if i is None:
                    continue
                bar=rows[i]
                # Pass opening price to model gap-through-stop fills; use close for remaining marks.
                if s in broker.state['positions']:
                    p=broker.state['positions'][s]
                    liquidation = bar.low<=p['liquidation'] if p['side']==1 else bar.high>=p['liquidation']
                    stop_hit = bar.low<=p['stop'] if p['side']==1 else bar.high>=p['stop']
                    trigger = bar.open if stop_hit else bar.close
                    broker.mark(s,trigger,t+interval-1,high=bar.high,low=bar.low,
                                mark_price=(bar.low if p['side']==1 else bar.high) if liquidation else bar.close)
            exposure+=bool(broker.state['positions'])
            curves.append([t+interval-1,broker.view()['equity']])
        final_time=timeline[-1]+interval
        for s in list(broker.state['positions']):
            broker.close_observed(s,broker.state['positions'][s]['last_price'],final_time,'end of backtest')
        final=broker.view()
        if curves:
            curves[-1][1]=final['equity']
        result=metrics(final['trades'],curves,config.initial_balance,interval)
        result['exposure_fraction']=exposure/len(timeline)
        by_symbol={}
        for symbol in series:
            trades=[x for x in final['trades'] if x['symbol']==symbol]
            by_symbol[symbol]=dict(trades=len(trades),net_pnl=sum(x['net_pnl'] for x in trades),
                                   fees=sum(x['entry_fee']+x['exit_fee'] for x in trades),
                                   funding=sum(x['funding'] for x in trades))
        report=dict(schema=2,kind='backtest',source=data['source'],dataset_hash=fingerprint(data),strategy=strategy,
                    execution_model=EXECUTION_MODEL,
                    historical_spread_bps=HISTORICAL_SPREAD_BPS,
                    start=start,end=end,config=asdict(config),metrics=result,by_symbol=by_symbol,
                    rejections=rejected,trades=final['trades'],equity_curve=curves,
                    assumptions=['Next-bar open entry; only prior closed bars generate signals',
                     'Stop before target when both are touched; gap fills use worse opening price',
                     'Fixed 2 bps full spread: 1 bp adverse half-spread on each leg, then configured slippage and taker fees',
                     'Historical funding events used when supplied; no invented funding history',
                     'Isolated-margin liquidation approximation; deficit reported separately',
                     'No queue, latency, partial-fill, historical liquidity, or delisted-universe reconstruction',
                     'Alignment strategy requires multi-timeframe data and produces no signal in single-timeframe backtests'])
        store.close()
        return report


def evaluate_strategy(data,config,strategy):
    """Chronological untouched test; no tuning on test data. Gate is conservative, not a guarantee."""
    times=sorted(set(x['time'] for item in data['symbols'].values() for x in item['candles']))
    usable=times[config.min_history:]
    if len(usable)<500:
        raise ValueError('Need at least 620 candles for strategy evaluation')
    split=usable[int(len(usable)*0.7)]
    validation=run_backtest(data,config,strategy,end=split)
    test=run_backtest(data,config,strategy,start=split)
    m=test['metrics']
    reasons=[]
    if data['source']=='synthetic-demo': reasons.append('Synthetic fixtures cannot qualify a strategy')
    if m['trades']<30: reasons.append('Fewer than 30 untouched-test trades')
    if m['net_pnl']<=0: reasons.append('No positive net test return')
    if m['max_drawdown']>config.max_drawdown: reasons.append('Drawdown exceeds configured limit')
    if m['profit_factor'] is None or m['profit_factor']<1.2: reasons.append('Profit factor below 1.2 or undefined')
    # Cost stress must also pass, with the same chosen strategy and untouched period.
    from dataclasses import replace
    stressed=run_backtest(data,replace(config,fee_rate=config.fee_rate*2,slippage_bps=config.slippage_bps*2),strategy,start=split)
    if stressed['metrics']['net_pnl']<=0: reasons.append('Fails doubled-fee/slippage stress')
    return dict(kind='strategy_evaluation',strategy=strategy,dataset_hash=fingerprint(data),source=data['source'],
                execution_model=test['execution_model'],historical_spread_bps=HISTORICAL_SPREAD_BPS,
                config=asdict(config),validation=validation['metrics'],test=m,stress=stressed['metrics'],
                test_start=split,test_end=times[-1],eligible=not reasons,reasons=reasons,
                note='Manual approval required; small-sample historical evidence does not establish future expectancy')
