"""Local isolated-margin paper ledger. No exchange order transport exists."""
import copy
from datetime import datetime, timezone
import hashlib
import json
import math
from dataclasses import asdict
import threading
from .models import Position, positive
from .risk import RiskEngine, equity, available


def periods(now):
    dt = datetime.fromtimestamp(now/1000, timezone.utc)
    iso = dt.isocalendar()
    return dt.date().isoformat(), f'{iso.year}-{iso.week}'


def initial_state(config):
    return dict(cash=config.initial_balance, initial=config.initial_balance, positions={}, trades=[],
                seen=[], killed=False, circuit='', high_water=config.initial_balance,
                day='', week='', day_equity=config.initial_balance, week_equity=config.initial_balance,
                cooldown_until=0, loss_streak=0, fees=0.0, funding=0.0, insurance_deficit=0.0,
                equity_curve=[], last_time=0, config=json.loads(json.dumps(asdict(config))))


class PaperBroker:
    def __init__(self, config, store, *, exit_half_spread_bps=0.0):
        if not isinstance(exit_half_spread_bps,(int,float)) or not math.isfinite(exit_half_spread_bps) or not 0 <= exit_half_spread_bps < 10000:
            raise ValueError('Exit half-spread must be finite, nonnegative and below 10000 bps')
        # Live callers already supply executable bid/ask quotes. Historical
        # OHLC exits instead supply a reference price, so replay adds its
        # declared half-spread here before slippage and fees.
        self.exit_half_spread_bps=exit_half_spread_bps
        self.c, self.store = config, store
        self.lock = threading.RLock()
        self.risk = RiskEngine(config)
        self.state = store.load() or initial_state(config)
        if self.state['initial'] != config.initial_balance:
            raise ValueError('Initial balance differs from persisted account; use a separate data directory')
        settings=json.loads(json.dumps(asdict(config)))
        if self.state.get('config',settings)!=settings and self.state['positions']:
            raise ValueError('Risk configuration changed with open positions; restore the previous configuration first')
        self.state['config']=settings
        self.store.commit(self.state, [])

    def _period(self, state, now):
        if now < state['last_time']:
            raise ValueError('Out-of-order account event')
        day, week = periods(now)
        e = equity(state)
        if state['day'] != day:
            state['day'],state['day_equity'] = day,e
        if state['week'] != week:
            state['week'],state['week_equity'] = week,e
        state['last_time'] = now
        state['high_water'] = max(state['high_water'],e)

    def _save(self,state,events):
        self.store.commit(state,events)
        self.state=state

    def view(self):
        with self.lock:
            s=copy.deepcopy(self.state)
            e=equity(s)
            s.update(equity=e,available_margin=available(s),used_margin=sum(p['margin'] for p in s['positions'].values()),
                     planned_risk=sum(p['risk'] for p in s['positions'].values()),
                     drawdown=1-e/s['high_water'],unrealized=e-s['cash'],
                     realized=sum(t['net_pnl'] for t in s['trades']),daily_pnl=e-s['day_equity'])
            return s

    def open(self,snapshot,signal,now,histories):
        with self.lock:
            s=copy.deepcopy(self.state)
            self._period(s,now)
            key=hashlib.sha256(f'{signal.symbol}:{signal.strategy}:{signal.side}:{signal.time}'.encode()).hexdigest()[:24]
            if key in s['seen']:
                decision=dict(approved=False,reason='Rejected: duplicate signal event')
            else:
                approval=self.risk.evaluate(s,snapshot,signal,now,histories)
                decision=approval.__dict__.copy()
                if approval.approved:
                    fee=approval.qty*approval.entry*self.c.fee_rate
                    p=Position(key,signal.symbol,signal.side,signal.strategy,approval.qty,approval.entry,approval.stop,
                               approval.target,self.c.leverage,approval.margin,approval.risk,now,now,snapshot.price,fee,
                               liquidation=approval.entry*(1-signal.side*(1/self.c.leverage-self.c.maintenance_margin)))
                    s['cash']-=fee
                    s['fees']+=fee
                    s['positions'][signal.symbol]=p.dict()
                    s['seen'].append(key)
            self._save(s,[(now,'risk_decision',dict(symbol=signal.symbol,strategy=signal.strategy,signal=signal.__dict__,**decision))])
            return decision

    def _close(self,s,symbol,price,now,reason,events,raw=False):
        p=Position(**s['positions'].pop(symbol))
        exit_price=price if raw else price*(1-p.side*self.exit_half_spread_bps/10000)*(1-p.side*self.c.slippage_bps/10000)
        gross=p.pnl(exit_price)
        fee=p.qty*exit_price*self.c.fee_rate
        settlement=gross-fee
        # Explicit isolated-margin bankruptcy assumption; never silently credit losses away.
        protected_margin=sum(x['margin'] for x in s['positions'].values())
        loss_collateral=min(p.margin,max(0,s['cash']-protected_margin))
        deficit=max(0,-loss_collateral-settlement)
        settlement=max(-loss_collateral,settlement)
        s['insurance_deficit']+=deficit
        s['cash']+=settlement
        s['fees']+=fee
        net=settlement-p.entry_fee-p.funding
        trade=dict(**p.dict(),closed=now,exit=exit_price,gross_pnl=gross,exit_fee=fee,net_pnl=net,
                   reason=reason,insurance_deficit=deficit)
        s['trades'].append(trade)
        if net<0:
            s['loss_streak']+=1
            if s['loss_streak']>=self.c.loss_streak:
                s['cooldown_until']=now+self.c.cooldown_seconds*1000
        else:
            s['loss_streak']=0
        events.append((now,'position_closed',trade))
        if s['cash'] < -1e-8:
            raise ArithmeticError('Ledger cash invariant failed')
        s['cash']=max(0,s['cash'])

    def mark(self,symbol,price,now,*,high=None,low=None,mark_price=None):
        if not positive(price) or (mark_price is not None and not positive(mark_price)):
            raise ValueError('Invalid market price')
        if high is not None and (not positive(high) or not positive(low) or not low<=price<=high):
            raise ValueError('Invalid intrabar range')
        with self.lock:
            if symbol not in self.state['positions']:
                return
            s=copy.deepcopy(self.state)
            self._period(s,now)
            p=Position(**s['positions'][symbol])
            if now <= p.last_time:
                return  # Duplicate market events have no side effects.
            hi,lo=(price,price) if high is None else (high,low)
            mark=mark_price or price
            liquidated=mark<=p.liquidation if p.side==1 else mark>=p.liquidation
            stop_hit=lo<=p.stop if p.side==1 else hi>=p.stop
            target_hit=hi>=p.target if p.side==1 else lo<=p.target
            events=[]
            if s['killed']:
                self._close(s,symbol,price,now,'emergency stop',events)
            elif liquidated:
                self._close(s,symbol,mark,now,'estimated isolated liquidation',events)
            elif stop_hit:
                fill=min(price,p.stop) if p.side==1 else max(price,p.stop)
                self._close(s,symbol,fill,now,'stop-loss (stop first if intrabar sequence unknown)',events)
            elif target_hit:
                self._close(s,symbol,p.target,now,'take-profit',events)
            elif now-p.opened >= self.c.max_hold_seconds*1000:
                self._close(s,symbol,price,now,'maximum holding time',events)
            else:
                s['positions'][symbol].update(last_price=price,last_time=now)
            e=equity(s)
            s['high_water']=max(s['high_water'],e)
            breach = ('drawdown circuit breaker' if e<=s['high_water']*(1-self.c.max_drawdown) else
                      'daily loss circuit breaker' if e<=s['day_equity']*(1-self.c.daily_loss) else
                      'weekly loss circuit breaker' if e<=s['week_equity']*(1-self.c.weekly_loss) else '')
            if breach:
                s['circuit']=breach
                for name, position in list(s['positions'].items()):
                    # Only current symbol has a fresh quote; do not fabricate fills for others.
                    if name==symbol:
                        self._close(s,name,position['last_price'],now,breach,events)
            elif s['circuit'] and symbol in s['positions']:
                self._close(s,symbol,price,now,s['circuit'],events)
            s['equity_curve'].append([now,equity(s)])
            s['equity_curve']=s['equity_curve'][-10000:]
            self._save(s,events)

    def funding(self,symbol,rate,mark,time_ms,now):
        if not positive(mark) or not isinstance(rate,(int,float)) or not -1<rate<1 or time_ms>now:
            raise ValueError('Invalid funding event')
        with self.lock:
            if symbol not in self.state['positions']:
                return
            s=copy.deepcopy(self.state)
            self._period(s,now)
            p=s['positions'][symbol]
            if time_ms<=p['opened'] or time_ms<=p['last_funding']:
                return
            charge=p['side']*p['qty']*mark*rate
            events=[]
            free=max(0,s['cash']-sum(x['margin'] for x in s['positions'].values()))
            other_margin=sum(x['margin'] for name,x in s['positions'].items() if name!=symbol)
            paid=min(charge,max(0,s['cash']-other_margin)) if charge>0 else charge
            s['insurance_deficit']+=max(0,charge-paid)
            s['cash']-=paid
            s['funding']+=paid
            p['funding']+=paid
            p['last_funding']=time_ms
            events.append((now,'funding',dict(symbol=symbol,charge=paid,unfunded=max(0,charge-paid),event_time=time_ms)))
            if charge>free:
                self._close(s,symbol,mark,now,'funding collateral protection',events)
            self._save(s,events)

    def kill(self,now):
        with self.lock:
            s=copy.deepcopy(self.state)
            s['killed']=True
            self._save(s,[(now,'emergency_stop',{'action':'latched; positions close at next fresh observed quote'})])

    def close_observed(self,symbol,price,now,reason):
        if not positive(price):
            raise ValueError('Invalid exit price')
        with self.lock:
            s=copy.deepcopy(self.state)
            self._period(s,now)
            if symbol not in s['positions']:
                return
            events=[]
            self._close(s,symbol,price,now,reason,events)
            self._save(s,events)
