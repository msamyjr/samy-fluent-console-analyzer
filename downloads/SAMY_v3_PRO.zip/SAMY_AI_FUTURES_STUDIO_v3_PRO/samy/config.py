from dataclasses import dataclass, asdict
import json
import math
from pathlib import Path


@dataclass(frozen=True)
class Config:
    initial_balance: float = 75.0
    max_positions: int = 2
    trade_risk: float = 0.005
    total_risk: float = 0.01
    leverage: float = 2.0
    max_leverage: float = 3.0
    max_margin_fraction: float = 0.5
    max_symbol_fraction: float = 0.6
    daily_loss: float = 0.02
    weekly_loss: float = 0.04
    max_drawdown: float = 0.08
    loss_streak: int = 3
    cooldown_seconds: int = 3600
    stale_seconds: int = 20
    max_spread_bps: float = 10.0
    min_quote_volume: float = 10_000_000.0
    fee_rate: float = 0.0005
    slippage_bps: float = 3.0
    funding_buffer: float = 0.001
    maintenance_margin: float = 0.005
    max_correlation: float = 0.8
    min_history: int = 120
    scan_batch: int = 3
    concurrency: int = 3
    scan_seconds: int = 30
    max_hold_seconds: int = 14400
    timeframes: tuple = ('1m', '5m', '15m', '30m', '1h', '4h', '1d')

    def __post_init__(self):
        object.__setattr__(self, 'timeframes', tuple(self.timeframes))
        for key, value in asdict(self).items():
            if isinstance(value, (int, float)) and (isinstance(value, bool) or not math.isfinite(value) or value <= 0):
                raise ValueError(f'{key} must be finite and positive')
        for key in ('max_positions', 'loss_streak', 'cooldown_seconds', 'stale_seconds', 'min_history', 'scan_batch', 'concurrency', 'scan_seconds', 'max_hold_seconds'):
            if type(getattr(self, key)) is not int:
                raise ValueError(f'{key} must be an integer')
        if not (self.max_positions <= 2 and self.trade_risk <= 0.005 and self.total_risk <= 0.01):
            raise ValueError('Hard ceiling: two positions, 0.5% per trade, 1% portfolio risk')
        if not (1 <= self.leverage <= self.max_leverage <= 3):
            raise ValueError('Leverage must be between 1 and 3; escalation is unsupported')
        if not (self.trade_risk <= self.total_risk <= self.daily_loss <= self.weekly_loss <= self.max_drawdown < 1):
            raise ValueError('Loss limits must be ordered and below 100%')
        for key in ('max_margin_fraction', 'max_symbol_fraction', 'max_correlation'):
            if getattr(self, key) > 1:
                raise ValueError(f'{key} must be <= 1')
        if self.min_history < 120 or self.min_history > 1000 or self.concurrency > 8 or self.scan_batch > 30:
            raise ValueError('History or concurrency outside supported bounds')
        if not self.timeframes or any(x not in INTERVALS for x in self.timeframes) or '1m' not in self.timeframes:
            raise ValueError('Use supported timeframes and include 1m')

    @classmethod
    def load(cls, path=None):
        return cls(**json.loads(Path(path).read_text(encoding='utf-8'))) if path else cls()


INTERVALS = {'1m': 60_000, '5m': 300_000, '15m': 900_000, '30m': 1_800_000,
             '1h': 3_600_000, '4h': 14_400_000, '1d': 86_400_000}
