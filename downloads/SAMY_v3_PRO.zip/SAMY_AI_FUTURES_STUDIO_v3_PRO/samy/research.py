"""Reproducible logistic baseline research; no auto-promotion or invented confidence."""
from dataclasses import asdict
import math
from statistics import mean,pstdev
from .models import Candle
from .indicators import features,correlation
from .dataset import validate_dataset,fingerprint
from .config import INTERVALS

FEATURES=('ema_gap_atr','rsi_centered','roc','volatility','relative_volume','zscore')


def vector(candles):
    f=features(candles)
    return [(f['ema12']-f['ema26'])/(f['atr'] or 1),(f['rsi']-50)/50,
            f['roc'],f['volatility'],min(f['relative_volume'],10),f['zscore']]


def sigmoid(x):
    return 1/(1+math.exp(-max(-40,min(40,x))))


def fit(xs,ys,steps=250):
    if len(xs)<50 or len(set(ys))<2:
        raise ValueError('Training requires at least 50 observations and both target classes')
    means=[mean(x[j] for x in xs) for j in range(len(FEATURES))]
    scales=[pstdev(x[j] for x in xs) or 1 for j in range(len(FEATURES))]
    zs=[[(v-m)/s for v,m,s in zip(x,means,scales)] for x in xs]
    w=[0.0]*len(FEATURES)
    b=0.0
    for _ in range(steps):
        errors=[sigmoid(b+sum(a*v for a,v in zip(w,z)))-y for z,y in zip(zs,ys)]
        b-=0.05*mean(errors)
        w=[a-0.05*(mean(e*z[j] for e,z in zip(errors,zs))+0.01*a) for j,a in enumerate(w)]
    return dict(means=means,scales=scales,weights=w,bias=b)


def predict(model,x):
    z=[(v-m)/s for v,m,s in zip(x,model['means'],model['scales'])]
    return sigmoid(model['bias']+sum(w*v for w,v in zip(model['weights'],z)))


def calibrate(probabilities,ys):
    logits=[math.log(max(1e-9,p)/max(1e-9,1-p)) for p in probabilities]
    a,b=1.0,0.0
    for _ in range(250):
        error=[sigmoid(a*x+b)-y for x,y in zip(logits,ys)]
        a-=0.02*mean(e*x for e,x in zip(error,logits))
        b-=0.02*mean(error)
    return dict(a=a,b=b)


def apply_calibration(cal,p):
    return sigmoid(cal['a']*math.log(max(1e-9,p)/max(1e-9,1-p))+cal['b'])


def scores(probabilities,ys):
    if not ys:
        raise ValueError('Empty evaluation set')
    bins=[]
    for i in range(10):
        rows=[(p,y) for p,y in zip(probabilities,ys) if i/10<=p<(i+1)/10 or (i==9 and p==1)]
        if rows:
            bins.append(dict(bin=i,count=len(rows),predicted=mean(x[0] for x in rows),observed=mean(x[1] for x in rows)))
    return dict(n=len(ys),brier=mean((p-y)**2 for p,y in zip(probabilities,ys)),
      log_loss=-mean(y*math.log(max(1e-9,p))+(1-y)*math.log(max(1e-9,1-p)) for p,y in zip(probabilities,ys)),
      accuracy=mean(int((p>=0.5)==bool(y)) for p,y in zip(probabilities,ys)),calibration=bins)


def train(data,config,horizon=5):
    validate_dataset(data)
    if type(horizon) is not int or not 1<=horizon<=60:
        raise ValueError('Horizon must be an integer from 1 to 60')
    rows=[]
    interval=INTERVALS[data['interval']]
    cost=2*config.fee_rate+2*config.slippage_bps/10000+0.0002+config.funding_buffer
    for symbol,item in data['symbols'].items():
        candles=[Candle(**x) for x in item['candles']]
        for i in range(config.min_history,len(candles)-horizon):
            x=vector(candles[i-config.min_history:i])
            # Features available at t, next open entry, horizon close target with explicit cost hurdle.
            target=int(candles[i+horizon-1].close/candles[i].open-1>cost)
            rows.append((candles[i].time,symbol,x,target,candles[i+horizon-1].time+interval))
    rows.sort(key=lambda x:(x[0],x[1]))
    times=sorted(set(x[0] for x in rows))
    if len(times)<500:
        raise ValueError('Need >=500 usable timestamps after warmup and horizon')
    validation_start=times[int(len(times)*0.6)]
    test_start=times[int(len(times)*0.8)]
    training=[r for r in rows if r[4]<validation_start]
    validation=[r for r in rows if validation_start<=r[0] and r[4]<test_start]
    test=[r for r in rows if r[0]>=test_start]
    model=fit([r[2] for r in training],[r[3] for r in training])
    cal=calibrate([predict(model,r[2]) for r in validation],[r[3] for r in validation])
    ps=[apply_calibration(cal,predict(model,r[2])) for r in test]
    ys=[r[3] for r in test]
    prevalence=mean(r[3] for r in training)
    baseline=scores([prevalence]*len(test),ys)
    momentum=scores([0.6 if r[2][2]>0 else 0.4 for r in test],ys)
    final=scores(ps,ys)
    folds=[]
    # Expanding chronological folds entirely before the untouched final test.
    for fraction in (0.3,0.4,0.5):
        boundary=times[int(len(times)*fraction)]
        finish=times[int(len(times)*(fraction+0.1))]
        tr=[r for r in rows if r[4]<boundary]
        va=[r for r in rows if boundary<=r[0] and r[4]<finish]
        m=fit([r[2] for r in tr],[r[3] for r in tr],steps=100)
        folds.append(dict(train_end=max(r[4] for r in tr),validation_start=boundary,
                          validation_end=finish,metrics=scores([predict(m,r[2]) for r in va],[r[3] for r in va])))
    importance=sorted([dict(feature=k,standardized_weight=v) for k,v in zip(FEATURES,model['weights'])],key=lambda x:-abs(x['standardized_weight']))
    redundant=[]
    for i,a in enumerate(FEATURES):
        for j,b in enumerate(FEATURES[:i]):
            corr=correlation({n:r[2][i] for n,r in enumerate(training)},{n:r[2][j] for n,r in enumerate(training)})
            if corr is not None and abs(corr)>0.8:
                redundant.append(dict(a=a,b=b,correlation=corr))
    return dict(kind='model_research',model='L2 logistic regression + validation-only Platt calibration',
      version=fingerprint(data)[:12],source=data['source'],dataset_hash=fingerprint(data),config=asdict(config),horizon=horizon,
      features=FEATURES,parameters=model,calibration_parameters=cal,
      split=dict(train_n=len(training),validation_n=len(validation),test_n=len(test),
                 train_label_end=max(r[4] for r in training),validation_start=validation_start,
                 validation_label_end=max(r[4] for r in validation),test_start=test_start),
      test=final,prevalence_baseline=baseline,momentum_baseline=momentum,walk_forward=folds,
      feature_weights=importance,redundant_features=redundant,
      beats_baselines=final['brier']<min(baseline['brier'],momentum['brier']),
      active=False,deployment='DISABLED: probability quality alone does not validate net trading expectancy',
      limitations=['Overlapping labels purged at split boundaries; dependent samples remain within periods',
                  'Funding buffer in target is an assumption, not reconstructed trade-specific funding',
                  'Long net-return target only; no short-target model or trading promotion',
                  'No hyperparameter search, statistical significance claim, or deep-learning model'])
