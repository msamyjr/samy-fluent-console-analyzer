"""The sole exchange transport: allowlisted, unsigned, GET-only public market data."""
import asyncio
from collections import deque
import json
import time
import threading
from urllib.request import Request, urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError, URLError
from .config import INTERVALS
from .models import Contract, Candle, Snapshot, validate_candles, positive
from .indicators import features

HOST = 'https://fapi.binance.com'
ENDPOINTS = {'time': ('/fapi/v1/time', 1), 'exchangeInfo': ('/fapi/v1/exchangeInfo', 1),
 'ticker': ('/fapi/v1/ticker/24hr', 40), 'depth': ('/fapi/v1/depth', 2),
 'klines': ('/fapi/v1/klines', 5), 'premium': ('/fapi/v1/premiumIndex', 1),
 'oi': ('/fapi/v1/openInterest', 1), 'funding': ('/fapi/v1/fundingRate', 1)}


class DataError(RuntimeError):
    pass


class PublicClient:
    def __init__(self, config, opener=urlopen):
        self.config, self.opener = config, opener
        self.limiter_lock = threading.Lock()
        self.weights = deque()
        self.cache = {}
        self.offset = 0
        self.synced_at = 0
        self.sem = asyncio.Semaphore(config.concurrency)
        self.previous_oi = {}
        self.last_ok = 0
        self.stopped = threading.Event()

    def _sleep(self, delay):
        if self.stopped.wait(delay):
            raise DataError('Market client stopped')

    def _reserve(self, weight):
        while True:
            if self.stopped.is_set():
                raise DataError('Market client stopped')
            with self.limiter_lock:
                now = time.monotonic()
                while self.weights and self.weights[0][0] < now-60:
                    self.weights.popleft()
                if sum(w for _, w in self.weights)+weight <= 600:
                    self.weights.append((now, weight))
                    return
                delay = max(0.01, 60-(now-self.weights[0][0]))
            self._sleep(delay)

    def get(self, name, params=None, ttl=0):
        if name not in ENDPOINTS:
            raise DataError('Endpoint is not public-market-data allowlisted')
        params = dict(params or {})
        if set(params) & {'signature', 'recvWindow', 'apiKey'}:
            raise DataError('Private request parameters are forbidden')
        path, weight = ENDPOINTS[name]
        key = (name, urlencode(sorted(params.items())))
        cached = self.cache.get(key)
        if cached and time.monotonic()-cached[0] < ttl:
            return cached[1]
        for attempt in range(3):
            self._reserve(weight)
            request = Request(HOST+path+('?' + key[1] if key[1] else ''),
                              headers={'User-Agent': 'SAMY-PAPER/3.0'}, method='GET')
            try:
                with self.opener(request, timeout=12) as response:
                    result = json.loads(response.read())
                if isinstance(result, dict) and result.get('code', 0) < 0:
                    raise DataError(f'Exchange rejected public data request: {result.get("code")}')
                if len(self.cache)>=1024:
                    oldest=min(self.cache,key=lambda k:self.cache[k][0])
                    del self.cache[oldest]
                self.cache[key] = time.monotonic(), result
                self.last_ok = int(time.time()*1000)
                return result
            except HTTPError as exc:
                if exc.code not in (429, 418, 500, 502, 503, 504):
                    raise DataError(f'Public data HTTP {exc.code}; check network policy or regional restrictions') from exc
                retry_after=float(exc.headers.get('Retry-After',1))
                if retry_after>60:
                    raise DataError(f'Rate-limit cooldown exceeds 60 seconds: retry after {retry_after}s') from exc
                delay = max(2**attempt,retry_after)
                if exc.code == 418 or attempt == 2:
                    raise DataError(f'Exchange rate-limit/server response: {exc.code}') from exc
            except (URLError, TimeoutError, OSError) as exc:
                if attempt == 2:
                    raise DataError(f'Public market data unavailable: {exc}') from exc
                delay = 2**attempt
            self._sleep(delay)
        raise DataError('Public request retries exhausted')

    async def request(self, *args, **kwargs):
        async with self.sem:
            return await asyncio.to_thread(self.get, *args, **kwargs)

    def sync(self):
        before = time.time()*1000
        server = int(self.get('time')['serverTime'])
        self.offset = server-(before+time.time()*1000)/2
        if abs(self.offset) > 60_000:
            raise DataError('Local clock differs from exchange by over one minute')
        self.synced_at = time.monotonic()
        return self.now()

    def now(self):
        return int(time.time()*1000+self.offset)

    def discover(self):
        metadata = self.get('exchangeInfo', ttl=3600)
        contracts = {}
        for item in metadata['symbols']:
            if item.get('contractType') != 'PERPETUAL' or item.get('quoteAsset') != 'USDT' or item.get('marginAsset') != 'USDT' or item.get('status') != 'TRADING':
                continue
            filters = {x['filterType']: x for x in item['filters']}
            try:
                lot = filters.get('MARKET_LOT_SIZE', filters['LOT_SIZE'])
                contracts[item['symbol']] = Contract(item['symbol'], float(filters['PRICE_FILTER']['tickSize']),
                    float(lot['stepSize']), float(lot['minQty']),
                    float(filters['MIN_NOTIONAL'].get('notional', filters['MIN_NOTIONAL'].get('minNotional'))), float(lot['maxQty']))
            except (KeyError, TypeError, ValueError):
                continue  # Unsupported/incomplete filters are never tradable.
        return contracts

    def candles(self, symbol, interval, limit=None, start=None, end=None):
        params = {'symbol': symbol, 'interval': interval, 'limit': limit or self.config.min_history+1}
        if start is not None:
            params['startTime'] = start
        if end is not None:
            params['endTime'] = end
        ttl = min(INTERVALS[interval]/1000/2, 60) if start is None else 0
        rows = self.get('klines', params, ttl=ttl)
        now = self.now()
        result = [Candle(int(x[0]), *map(float, x[1:6])) for x in rows if int(x[6]) < now]
        if start is not None and not result:
            return []
        return validate_candles(result, INTERVALS[interval], 1 if start is not None else self.config.min_history)

    async def snapshot(self, contract, ticker):
        symbol = contract.symbol
        tasks = [self.request('depth', {'symbol':symbol,'limit':20}),
                 self.request('premium', {'symbol':symbol}), self.request('oi', {'symbol':symbol})]
        tasks += [self._candles_async(symbol, tf) for tf in self.config.timeframes]
        results = await asyncio.gather(*tasks)
        book, premium, oi = results[:3]
        candles = dict(zip(self.config.timeframes, results[3:]))
        bids, asks = book['bids'], book['asks']
        bid, ask = float(bids[0][0]), float(asks[0][0])
        book_time = int(book.get('T', book.get('E', 0)))
        premium_time = int(premium.get('time', 0))
        oi_time = int(oi.get('time', 0))
        now = self.now()
        if any(abs(now-t) > self.config.stale_seconds*1000 for t in (book_time,premium_time,oi_time)):
            raise DataError('Stale or future-dated market snapshot')
        if now-(candles['1m'][-1].time+INTERVALS['1m']) > 90_000:
            raise DataError('Stale candles')
        bv, av = sum(float(x[1]) for x in bids), sum(float(x[1]) for x in asks)
        price = (bid+ask)/2
        if not (positive(bid) and ask >= bid and positive(float(premium['markPrice']))):
            raise DataError('Invalid bid/ask or mark price')
        current_oi = float(oi['openInterest'])
        previous = self.previous_oi.get(symbol)
        self.previous_oi[symbol] = current_oi
        return Snapshot(contract, min(book_time,premium_time,oi_time), price, bid, ask,
                        float(ticker['quoteVolume']), (bv-av)/(bv+av or 1), float(premium['lastFundingRate']),
                        current_oi, candles, features(candles['1m'])['returns'],
                        oi_change=(current_oi/previous-1) if previous else None,
                        next_funding_time=int(premium.get('nextFundingTime',0)), mark_price=float(premium['markPrice']))

    async def _candles_async(self, symbol, tf):
        async with self.sem:
            return await asyncio.to_thread(self.candles, symbol, tf)

    def funding_history(self, symbol, start, end):
        output = []
        while start <= end:
            rows = self.get('funding', {'symbol':symbol, 'startTime':start, 'endTime':end, 'limit':1000})
            if not rows:
                break
            output.extend({'time':int(x['fundingTime']), 'rate':float(x['fundingRate']), 'mark':float(x['markPrice'])} for x in rows)
            start = int(rows[-1]['fundingTime'])+1
            if len(rows)<1000:
                break
        return output
