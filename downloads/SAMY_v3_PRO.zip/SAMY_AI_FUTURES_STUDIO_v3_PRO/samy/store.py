import json
import sqlite3
import threading
from contextlib import closing
from pathlib import Path


class Store:
    """Single transactional state + append-only audit trail, WAL recovery."""
    def __init__(self, path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.db = sqlite3.connect(path, check_same_thread=False, timeout=10)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS state(id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, time INTEGER NOT NULL, kind TEXT NOT NULL, payload TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS artifacts(id TEXT PRIMARY KEY, kind TEXT NOT NULL, payload TEXT NOT NULL);
        ''')
        self.db.commit()
        if self.db.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
            raise RuntimeError('Database integrity check failed; preserve database and restore a backup')

    def load(self):
        with self.lock:
            row = self.db.execute('SELECT value FROM state WHERE id=1').fetchone()
            return json.loads(row[0]) if row else None

    def commit(self, state, events):
        with self.lock, self.db:
            self.db.execute('INSERT OR REPLACE INTO state VALUES(1,?)', (json.dumps(state, allow_nan=False),))
            self.db.executemany('INSERT INTO events(time,kind,payload) VALUES(?,?,?)',
                [(t, k, json.dumps(v, allow_nan=False)) for t,k,v in events])

    def events(self, limit=100):
        with self.lock:
            return [dict(id=r[0], time=r[1], kind=r[2], payload=json.loads(r[3])) for r in
                    self.db.execute('SELECT id,time,kind,payload FROM events ORDER BY id DESC LIMIT ?', (limit,))]

    def artifact(self, key, kind, value):
        with self.lock, self.db:
            self.db.execute('INSERT OR REPLACE INTO artifacts VALUES(?,?,?)', (key,kind,json.dumps(value,allow_nan=False)))

    def artifacts(self, kind):
        with self.lock:
            return [json.loads(x[0]) for x in self.db.execute('SELECT payload FROM artifacts WHERE kind=?', (kind,))]

    def backup(self, target):
        # A Connection context manager commits/rolls back; it does not close.
        # Windows cannot remove the backup file while that handle remains open.
        with self.lock, closing(sqlite3.connect(target)) as backup:
            self.db.backup(backup)

    def close(self):
        with self.lock:
            self.db.close()
