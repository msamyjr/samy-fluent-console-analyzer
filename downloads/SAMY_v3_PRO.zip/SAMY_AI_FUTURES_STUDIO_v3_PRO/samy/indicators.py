"""Causal indicators. No centered windows or future-dependent swing labels."""
import math
from statistics import mean, pstdev


def ema(values, period):
    result = [values[0]]
    alpha = 2 / (period + 1)
    for x in values[1:]:
        result.append(alpha * x + (1 - alpha) * result[-1])
    return result


def rsi(values, period=14):
    changes = [b - a for a, b in zip(values, values[1:])]
    gain = mean([max(0, x) for x in changes[-period:]])
    loss = mean([max(0, -x) for x in changes[-period:]])
    return 100 * gain / (gain + loss) if gain + loss else 50.0


def correlation(a, b):
    times = sorted(set(a) & set(b))
    if len(times) < 30:
        return None
    x, y = [a[t] for t in times], [b[t] for t in times]
    mx, my = mean(x), mean(y)
    denominator = math.sqrt(sum((v-mx)**2 for v in x) * sum((v-my)**2 for v in y))
    return sum((u-mx)*(v-my) for u, v in zip(x, y)) / denominator if denominator else None


def features(candles):
    c = [x.close for x in candles]
    fast, slow = ema(c, 12), ema(c, 26)
    tr = [max(x.high-x.low, abs(x.high-p.close), abs(x.low-p.close)) for p, x in zip(candles, candles[1:])]
    atr = mean(tr[-14:])
    mid, sd = mean(c[-20:]), pstdev(c[-20:])
    logs = [math.log(b/a) for a, b in zip(c[-61:], c[-60:])]
    returns = {b.time: math.log(b.close/a.close) for a, b in zip(candles, candles[1:])}
    up = [max(0, b.high-a.high) if b.high-a.high > a.low-b.low else 0 for a,b in zip(candles, candles[1:])]
    down = [max(0, a.low-b.low) if a.low-b.low > b.high-a.high else 0 for a,b in zip(candles, candles[1:])]
    # Rolling directional index: transparent approximation, not Wilder's ADX.
    dx = 100*abs(sum(up[-14:])-sum(down[-14:]))/(sum(up[-14:])+sum(down[-14:]) or 1)
    volume = sum(x.volume for x in candles[-20:])
    vwap = sum((x.high+x.low+x.close)/3*x.volume for x in candles[-20:])/(volume or 1)
    macd_series = [a-b for a,b in zip(fast,slow)]
    return {
        'price': c[-1], 'ema12': fast[-1], 'ema26': slow[-1], 'sma20': mid,
        'atr': atr, 'rsi': rsi(c), 'macd': macd_series[-1], 'macd_signal': ema(macd_series,9)[-1],
        'roc': c[-1]/c[-11]-1, 'volatility': pstdev(logs), 'directional_index': dx,
        'bb_upper': mid+2*sd, 'bb_lower': mid-2*sd, 'keltner_upper': mid+2*atr,
        'keltner_lower': mid-2*atr, 'vwap': vwap,
        'relative_volume': candles[-1].volume/(mean(x.volume for x in candles[-21:-1]) or 1),
        'resistance': max(x.high for x in candles[-21:-1]),
        'support': min(x.low for x in candles[-21:-1]),
        'zscore': (c[-1]-mid)/(sd or 1), 'returns': returns,
        'obv': sum((1 if b.close>a.close else -1 if b.close<a.close else 0)*b.volume for a,b in zip(candles,candles[1:])),
    }


def regime(f):
    if f['volatility'] > 0.025:
        return 'UNSTABLE'
    if f['volatility'] < 0.0001:
        return 'LOW VOLATILITY'
    if f['directional_index'] > 25 and abs(f['ema12']-f['ema26']) > f['atr']*0.2:
        return 'BULL TREND' if f['ema12']>f['ema26'] else 'BEAR TREND'
    return 'SIDEWAYS'
