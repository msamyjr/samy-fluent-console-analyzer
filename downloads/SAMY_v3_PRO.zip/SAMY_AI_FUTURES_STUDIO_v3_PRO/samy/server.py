from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import json
import secrets
import time

ASSETS=Path(__file__).parent/'web'


def make_server(service,port=8765):
    token=secrets.token_urlsafe(32)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self,fmt,*args):
            pass

        def valid_host(self):
            return self.headers.get('Host') in {f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'}

        def send(self,status,body,content_type='application/json'):
            if not isinstance(body,bytes):
                body=json.dumps(body,allow_nan=False).encode()
            self.send_response(status)
            self.send_header('Content-Type',content_type)
            self.send_header('Content-Length',str(len(body)))
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if not self.valid_host():
                return self.send(403,{'error':'Local Host header required'})
            if self.path=='/api/state':
                return self.send(200,service.view())
            if self.path=='/api/export':
                return self.send(200,dict(mode='PAPER ONLY',source=service.status['source'],account=service.broker.view(),events=service.store.events(10000)))
            if self.path in ('/','/index.html'):
                body=(ASSETS/'index.html').read_text(encoding='utf-8').replace('__TOKEN__',token).encode()
                return self.send(200,body,'text/html; charset=utf-8')
            files={'/app.js':('app.js','text/javascript; charset=utf-8'),'/style.css':('style.css','text/css; charset=utf-8')}
            if self.path in files:
                name,mime=files[self.path]
                return self.send(200,(ASSETS/name).read_bytes(),mime)
            return self.send(404,{'error':'Not found'})

        def do_POST(self):
            if not self.valid_host() or not secrets.compare_digest(self.headers.get('X-Samy-Token',''),token):
                return self.send(403,{'error':'Local session token required'})
            if self.headers.get('Content-Type')!='application/json':
                return self.send(415,{'error':'JSON required'})
            if self.path!='/api/kill':
                return self.send(404,{'error':'Unknown operation'})
            service.broker.kill(int(time.time()*1000))
            return self.send(200,{'status':'STOP LATCHED; no new positions; holdings exit at next fresh quote'})

    return ThreadingHTTPServer(('127.0.0.1',port),Handler)
