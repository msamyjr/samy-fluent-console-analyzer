"""SAMY AI FUTURES STUDIO: local paper execution only."""
__version__ = '3.0.1'
