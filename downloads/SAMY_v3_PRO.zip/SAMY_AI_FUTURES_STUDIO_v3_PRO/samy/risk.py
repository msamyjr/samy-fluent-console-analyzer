from dataclasses import dataclass
import math
from .models import Position, positive, quantize
from .indicators import correlation


@dataclass(frozen=True)
class Approval:
    approved: bool
    reason: str
    qty: float = 0.0
    entry: float = 0.0
    stop: float = 0.0
    target: float = 0.0
    risk: float = 0.0
    margin: float = 0.0


def equity(state):
    return state['cash'] + sum(max(-p['margin'], Position(**p).pnl()) for p in state['positions'].values())


def available(state):
    return max(0, equity(state) - sum(x['margin'] for x in state['positions'].values()))


class RiskEngine:
    def __init__(self, config):
        self.c = config

    def evaluate(self, state, snapshot, signal, now, histories):
        def reject(reason):
            return Approval(False, 'Rejected: '+reason)
        c = self.c
        e = equity(state)
        if state['killed']:
            return reject('emergency stop is latched')
        if state.get('circuit'):
            return reject(state['circuit'])
        if not positive(e):
            return reject('account equity is exhausted')
        if state['high_water'] > 0 and e/state['high_water']-1 <= -c.max_drawdown:
            return reject('drawdown circuit breaker')
        if e <= state['day_equity']*(1-c.daily_loss):
            return reject('daily loss circuit breaker')
        if e <= state['week_equity']*(1-c.weekly_loss):
            return reject('weekly loss circuit breaker')
        if now < state['cooldown_until']:
            return reject('consecutive-loss cooldown')
        if now-snapshot.time > c.stale_seconds*1000 or snapshot.time > now+1000:
            return reject('stale or future-dated market data')
        if now-signal.time > 90_000 or signal.time > now:
            return reject('stale signal')
        if signal.symbol != snapshot.contract.symbol:
            return reject('signal contract mismatch')
        if snapshot.source not in ('binance-public', 'synthetic-demo', 'historical'):
            return reject('unsupported data source')
        values = (snapshot.price,snapshot.bid,snapshot.ask,snapshot.quote_volume,snapshot.open_interest)
        if not all(positive(x) for x in values) or not math.isfinite(snapshot.funding):
            return reject('invalid market data')
        if snapshot.ask < snapshot.bid or not snapshot.bid <= snapshot.price <= snapshot.ask:
            return reject('invalid bid/ask')
        if snapshot.spread_bps > c.max_spread_bps:
            return reject('unacceptable spread')
        if snapshot.quote_volume < c.min_quote_volume:
            return reject('insufficient liquidity')
        symbol = signal.symbol
        if symbol in state['positions']:
            return reject('position already open for this symbol')
        if len(state['positions']) >= c.max_positions:
            return reject('maximum simultaneous positions reached')
        for name in state['positions']:
            corr = correlation(snapshot.returns, histories.get(name, {}))
            if corr is None:
                return reject('insufficient aligned correlation history')
            if abs(corr) >= c.max_correlation:
                return reject('correlated exposure exceeds portfolio limit')
        side = signal.side
        entry = (snapshot.ask if side == 1 else snapshot.bid)*(1+side*c.slippage_bps/10000)
        entry = quantize(entry,snapshot.contract.tick,up=side==1)
        stop = quantize(signal.stop,snapshot.contract.tick,up=side==-1)
        target = quantize(signal.target,snapshot.contract.tick,up=side==-1)
        distance = side*(entry-stop)
        if distance <= 0 or side*(target-entry) <= 0:
            return reject('stop or target is on the wrong side of entry')
        if distance/entry >= (1/c.leverage-c.maintenance_margin)*0.5:
            return reject('stop is too close to estimated liquidation level')
        # Reserve round-trip fees, exit slippage/spread, and funding in the loss budget.
        cost_per_unit = entry*(2*c.fee_rate+(c.slippage_bps+snapshot.spread_bps/2)/10000+c.funding_buffer)
        unit_risk = distance+cost_per_unit
        volatility_scale = min(1, 0.005/max(signal.volatility,0.000001))
        remaining = max(0,e*c.total_risk-sum(x['risk'] for x in state['positions'].values()))
        budget = min(e*c.trade_risk*volatility_scale,remaining)
        max_notional = min(e*c.max_symbol_fraction*c.leverage,
                           max(0,e*c.max_margin_fraction-sum(x['margin'] for x in state['positions'].values()))*c.leverage,
                           available(state)/(1/c.leverage+c.fee_rate))
        raw_qty = min(budget/unit_risk, max_notional/entry, snapshot.contract.max_qty)
        if raw_qty <= 0:
            return reject('risk or available margin exhausted')
        qty = quantize(raw_qty,snapshot.contract.step)
        notional = qty*entry
        if qty < snapshot.contract.min_qty or notional < snapshot.contract.min_notional:
            return reject('exchange minimum does not fit account and risk budget')
        if qty <= 0 or qty*unit_risk > budget+1e-10:
            return reject('quantity violates planned risk budget')
        if side*(target-entry) <= cost_per_unit:
            return reject('target distance does not exceed estimated costs; expected edge unproven')
        return Approval(True,'Approved for paper simulation: sizing and portfolio limits satisfied',qty,entry,stop,target,
                        qty*unit_risk,notional/c.leverage)
