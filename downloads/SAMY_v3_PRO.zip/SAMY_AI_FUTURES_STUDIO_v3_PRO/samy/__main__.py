import argparse
from dataclasses import asdict
from datetime import datetime,timezone
import json
import logging
import os
from pathlib import Path
import sys
import time
from . import __version__
from .config import Config,INTERVALS
from .dataset import synthetic_dataset,save_dataset,load_dataset,fingerprint
from .store import Store
from .broker import PaperBroker
from .backtest import run_backtest,evaluate_strategy
from .research import train
from .service import Service,approval_reasons
from .server import make_server
from .data import PublicClient
from .strategies import STRATEGIES


def timestamp(value):
    if value is None:
        return None
    try:
        dt=datetime.fromisoformat(value.replace('Z','+00:00'))
        if dt.tzinfo is None:
            dt=dt.replace(tzinfo=timezone.utc)
        return int(dt.timestamp()*1000)
    except ValueError as exc:
        raise argparse.ArgumentTypeError('Use an ISO UTC date such as 2026-10-01T00:00:00Z') from exc


class ProcessLock:
    def __init__(self,path):
        self.file=open(path,'a+b')
        self.file.seek(0)
        if not self.file.read(1):
            self.file.write(b'0')
            self.file.flush()
        self.file.seek(0)
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(self.file.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(self.file,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:
            self.file.close()
            raise RuntimeError('Another server owns this data directory. Use a different --data-dir.')

    def close(self):
        self.file.close()


def write_report(path,report):
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(f'Report: {path}')


def collect(args,config):
    client=PublicClient(config)
    client.sync()
    contracts=client.discover()
    if not all(s in contracts for s in args.symbols):
        raise ValueError('All requested symbols must be currently trading USDT-M perpetual contracts')
    end=args.end or client.now()
    start=args.start
    if end<=start:
        raise ValueError('End must follow start')
    data=dict(schema=1,source='binance-public',interval=args.interval,created=int(time.time()*1000),
              limitations=['Present-day contract universe and filters; survivorship bias not eliminated',
                           'No historical depth or quote-volume eligibility; fixed backtest spread assumption'],symbols={})
    for symbol in args.symbols:
        bars=[]
        cursor=start
        while cursor<end:
            rows=client.candles(symbol,args.interval,limit=1000,start=cursor,end=end)
            if not rows:
                break
            bars.extend(c for c in rows if c.time>=start and c.time<end)
            next_cursor=rows[-1].time+INTERVALS[args.interval]
            if next_cursor<=cursor:
                raise RuntimeError('Historical pagination did not advance')
            cursor=next_cursor
            if len(rows)<999:
                break
        data['symbols'][symbol]=dict(contract=asdict(contracts[symbol]),candles=[asdict(c) for c in bars],
                                     funding=client.funding_history(symbol,start,end))
    save_dataset(args.output,data)
    print(f'Saved public Futures dataset: {args.output}')


def main(argv=None):
    parser=argparse.ArgumentParser(description='SAMY AI FUTURES STUDIO v3 PRO — PAPER ONLY')
    parser.add_argument('--version',action='version',version=__version__)
    parser.add_argument('--config',help='Validated JSON risk/scanner configuration')
    parser.add_argument('--data-dir',help='Persistent directory (default data/market; serve --demo uses data/demo)')
    sub=parser.add_subparsers(dest='command',required=True)
    serve=sub.add_parser('serve',help='Launch local dashboard and bounded scanner')
    serve.add_argument('--demo',action='store_true',help='Use labeled synthetic fixtures; autonomous entries disabled')
    serve.add_argument('--port',type=int,default=8765)
    demo=sub.add_parser('demo-data',help='Write a reproducible synthetic research dataset')
    demo.add_argument('--output',default='data/demo.json')
    demo.add_argument('--candles',type=int,default=2400)
    demo.add_argument('--seed',type=int,default=17)
    fetch=sub.add_parser('collect',help='Collect public USDT-M history, without keys')
    fetch.add_argument('--symbols',nargs='+',required=True)
    fetch.add_argument('--interval',choices=INTERVALS,default='1m')
    fetch.add_argument('--start',type=timestamp,required=True)
    fetch.add_argument('--end',type=timestamp)
    fetch.add_argument('--output',default='data/history.json')
    for command in ('backtest','evaluate','train'):
        p=sub.add_parser(command)
        p.add_argument('dataset')
        p.add_argument('--output',default=f'reports/{command}.json')
        if command!='train':
            p.add_argument('--strategy',choices=STRATEGIES,default='adaptive')
        if command=='backtest':
            p.add_argument('--start',type=timestamp)
            p.add_argument('--end',type=timestamp)
        if command=='train':
            p.add_argument('--horizon',type=int,default=5)
    approve=sub.add_parser('approve',help='Manually approve a qualifying saved strategy evaluation')
    approve.add_argument('evaluation_id')
    backup=sub.add_parser('backup',help='Create a consistent SQLite backup')
    backup.add_argument('output')
    sub.add_parser('stop',help='Latch emergency stop in a stopped account; do not run beside serve')
    args=parser.parse_args(argv)
    config=Config.load(args.config)
    root=Path(args.data_dir or ('data/demo' if args.command=='serve' and args.demo else 'data/market'))
    root.mkdir(parents=True,exist_ok=True)
    if args.command=='demo-data':
        if not 620<=args.candles<=100000:
            raise ValueError('Use 620 to 100000 candles')
        save_dataset(args.output,synthetic_dataset(args.candles,args.seed))
        print(f'SYNTHETIC ONLY: {args.output}')
        return
    if args.command=='collect':
        collect(args,config)
        return
    store=Store(root/'paper.sqlite')
    try:
        if args.command in ('backtest','evaluate','train'):
            data=load_dataset(args.dataset)
            if args.command=='backtest':
                report=run_backtest(data,config,args.strategy,args.start,args.end)
            elif args.command=='evaluate':
                report=evaluate_strategy(data,config,args.strategy)
            else:
                report=train(data,config,args.horizon)
            report['created']=int(time.time()*1000)
            key=fingerprint(report)[:16]
            report['id']=key
            store.artifact(key,dict(backtest='backtest',evaluate='evaluation',train='model')[args.command],report)
            write_report(args.output,report)
            print(f'Evidence ID: {key}; source: {data["source"]}')
            print(json.dumps(report.get('metrics',report.get('test',{})),indent=2))
            if args.command=='evaluate':
                print('Eligible:',report['eligible'],'Reasons:',report['reasons'])
        elif args.command=='approve':
            reports=[r for r in store.artifacts('evaluation') if r.get('id')==args.evaluation_id]
            if len(reports)!=1:
                raise ValueError('Evaluation ID not found; run evaluate first')
            report=reports[0]
            reasons=approval_reasons(report,config,int(time.time()*1000))
            if reasons:
                raise ValueError('Approval rejected: '+'; '.join(reasons))
            store.artifact(report['strategy'],'approved_strategy',report)
            print('Approved for local paper simulation only:',report['strategy'])
        elif args.command=='backup':
            target=Path(args.output)
            if target.exists():
                raise ValueError('Backup destination already exists; choose a new file')
            target.parent.mkdir(parents=True,exist_ok=True)
            store.backup(target)
            print('Consistent backup saved:',target)
        elif args.command=='stop':
            lock=ProcessLock(root/'server.lock')
            try:
                PaperBroker(config,store).kill(int(time.time()*1000))
            finally:
                lock.close()
            print('Emergency stop latched. No automatic reset is provided.')
        elif args.command=='serve':
            lock=ProcessLock(root/'server.lock')
            service=None
            server=None
            try:
                account=PaperBroker(config,store)
                # Demo and market ledgers must never share an account.
                source='synthetic-demo' if args.demo else 'binance-public'
                markers=store.artifacts('account_source')
                if markers and markers[0]['source']!=source:
                    raise ValueError('Demo and Binance require separate --data-dir directories')
                store.artifact('account_source','account_source',dict(source=source))
                logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s',
                                    handlers=[logging.FileHandler(root/'system.log',encoding='utf-8'),logging.StreamHandler()])
                service=Service(config,store,account,args.demo)
                server=make_server(service,args.port)
                service.start()
                print(f'PAPER ONLY dashboard listening on loopback port {server.server_port}. Ctrl+C to stop.',flush=True)
                server.serve_forever(poll_interval=0.25)
            except KeyboardInterrupt:
                print('\nStopping scanner; account state is retained.')
            finally:
                if server:
                    server.server_close()
                if service:
                    service.shutdown()
                lock.close()
    finally:
        store.close()


if __name__=='__main__':
    try:
        main()
    except (ValueError,RuntimeError,OSError,KeyError) as exc:
        print(f'SAMY error: {exc}',file=sys.stderr)
        sys.exit(1)
