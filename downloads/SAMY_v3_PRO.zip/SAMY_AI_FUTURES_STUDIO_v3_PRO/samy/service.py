import asyncio
from dataclasses import asdict
import json
import logging
import threading
import time
from .data import PublicClient,DataError
from .dataset import synthetic_dataset,fingerprint
from .models import Candle,Contract,Snapshot
from .indicators import features,regime
from .strategies import STRATEGIES,generate

log=logging.getLogger('samy')


def approval_reasons(report,config,now):
    reasons=[]
    if report.get('kind')!='strategy_evaluation' or not report.get('eligible'):
        reasons.append('Evaluation did not qualify')
    if report.get('source') not in ('binance-public','imported-historical'):
        reasons.append('Non-market dataset')
    if fingerprint(report.get('config',{}))!=fingerprint(asdict(config)):
        reasons.append('Risk/cost configuration differs from evaluation')
    if not 0<=now-report.get('test_end',0)<=30*86400000:
        reasons.append('Evidence must end within the last 30 days')
    metrics=report.get('test',{})
    if metrics.get('trades',0)<30 or metrics.get('net_pnl',0)<=0 or (metrics.get('profit_factor') or 0)<1.2:
        reasons.append('Test trade count or net performance inadequate')
    if report.get('stress',{}).get('net_pnl',0)<=0:
        reasons.append('Cost stress failed')
    return reasons


class Service:
    def __init__(self,config,store,broker,demo=False):
        self.c,self.store,self.broker,self.demo=config,store,broker,demo
        self.client=PublicClient(config)
        self.lock=threading.RLock()
        self.stop=threading.Event()
        self.thread=None
        self.cursor=0
        self.histories={}
        self.status=dict(mode='PAPER ONLY',source='SYNTHETIC DEMO' if demo else 'BINANCE PUBLIC',
                         scanner='STARTING',connectivity='NOT CHECKED',model='DISABLED — research only',
                         eligible_markets=0,scanned=0,last_scan=0,last_error='',data_fresh=False)
        self.rows={}
        self.approved={}

    def _update(self,**values):
        with self.lock:
            self.status.update(values)

    def start(self):
        if self.thread:
            return
        self.thread=threading.Thread(target=lambda:asyncio.run(self.run()),daemon=True,name='scanner')
        self.thread.start()

    def view(self):
        with self.lock:
            status=self.status.copy()
            now=int(time.time()*1000)
            rows=sorted([dict(v,stale=now-v['time']>self.c.stale_seconds*1000) for v in self.rows.values()],key=lambda x:-x.get('score',0))
        status['data_fresh']=bool(status['last_scan'] and now-status['last_scan']<=self.c.stale_seconds*1000)
        return dict(health=status,account=self.broker.view(),markets=rows,
                    strategies=STRATEGIES,approvals=list(self.approved),events=self.store.events(60),
                    models=[{k:v for k,v in m.items() if k not in ('parameters',)} for m in self.store.artifacts('model')],
                    backtests=self.store.artifacts('backtest')[-10:])

    def _reload_approvals(self,now):
        approved={}
        for report in self.store.artifacts('approved_strategy'):
            if not approval_reasons(report,self.c,now):
                approved[report['strategy']]=report
        self.approved=approved

    async def _manage(self,snapshot,now):
        symbol=snapshot.contract.symbol
        p=self.broker.state['positions'].get(symbol)
        if not p:
            return
        if self.broker.state['killed'] or self.broker.state['circuit']:
            self.broker.close_observed(symbol,snapshot.bid if p['side']==1 else snapshot.ask,now,'emergency/circuit exit')
            return
        if not self.demo:
            events=await asyncio.to_thread(self.client.funding_history,symbol,max(p['opened'],p['last_funding'])+1,now)
            for f in events:
                self.broker.funding(symbol,f['rate'],f['mark'],f['time'],now)
        self.broker.mark(symbol,snapshot.bid if p['side']==1 else snapshot.ask,now,mark_price=snapshot.mark_price)

    async def _process(self,snapshot,now,execute=True):
        symbol=snapshot.contract.symbol
        self.histories[symbol]=snapshot.returns
        await self._manage(snapshot,now)
        f=features(snapshot.candles['1m'])
        signals=[s for key in STRATEGIES if (s:=generate(snapshot,key))]
        signals.sort(key=lambda s:-s.score)
        chosen=next((s for s in signals if s.strategy in self.approved), signals[0] if signals else None)
        reason='WAIT: no strategy conditions satisfied'
        action='WAIT'
        if chosen:
            action='LONG CANDIDATE' if chosen.side==1 else 'SHORT CANDIDATE'
            if snapshot.source=='synthetic-demo':
                reason='RESEARCH ONLY: synthetic data cannot qualify autonomous trading'
            elif chosen.strategy not in self.approved:
                reason='RESEARCH ONLY: strategy lacks approved out-of-sample evidence'
            elif execute:
                result=self.broker.open(snapshot,chosen,now,self.histories)
                reason=result['reason']
                if not result['approved']:
                    action='REJECTED BY RISK ENGINE'
            else:
                reason='Qualified candidate; awaiting ranked portfolio selection'
        row=dict(symbol=symbol,price=snapshot.price,spread_bps=snapshot.spread_bps,quote_volume=snapshot.quote_volume,
                 funding=snapshot.funding,open_interest=snapshot.open_interest,oi_change=snapshot.oi_change,
                 imbalance=snapshot.imbalance,regime=regime(f),volatility=f['volatility'],relative_volume=f['relative_volume'],
                 score=chosen.score if chosen else 0,signal=action,reason=reason,strategy=chosen.strategy if chosen else None,
                 time=snapshot.time,features={k:v for k,v in f.items() if k!='returns'},
                 timeframes={tf:dict(regime=regime(features(cs)),price=cs[-1].close) for tf,cs in snapshot.candles.items()},
                 source=snapshot.source)
        with self.lock:
            self.rows[symbol]=row
        return chosen

    async def cycle(self):
        now=int(time.time()*1000)
        self._reload_approvals(now)
        if self.demo:
            # Roll a seeded artificial history to current wall time; always visibly synthetic.
            data=synthetic_dataset(count=200,seed=17,start=now//60000*60000-200*60000)
            for symbol,item in data['symbols'].items():
                cs=[Candle(**x) for x in item['candles']]
                price=cs[-1].close
                snapshot=Snapshot(Contract(**item['contract']),now,price,price*0.9999,price*1.0001,
                                  100_000_000,0,0.0001,1000,{'1m':cs},features(cs)['returns'],source='synthetic-demo',mark_price=price)
                await self._process(snapshot,now)
            self._update(scanner='SCANNING SYNTHETIC FIXTURES',connectivity='OFFLINE DEMO',eligible_markets=3,
                         scanned=3,last_scan=now,last_error='')
            return
        if time.monotonic()-self.client.synced_at>300:
            await asyncio.to_thread(self.client.sync)
        contracts=await asyncio.to_thread(self.client.discover)
        tickers=await self.client.request('ticker',ttl=10)
        liquid={x['symbol']:x for x in tickers if x['symbol'] in contracts and float(x['quoteVolume'])>=self.c.min_quote_volume}
        symbols=sorted(liquid)
        if not symbols:
            raise DataError('No contracts satisfy metadata and liquidity requirements')
        # Manage every holding each cycle, regardless of its current liquidity rank.
        held=list(self.broker.state['positions'])
        if any(s not in contracts for s in held):
            raise DataError('Held contract no longer supported; manual data investigation required, no invented fill')
        batch=[symbols[(self.cursor+i)%len(symbols)] for i in range(min(self.c.scan_batch,len(symbols)))]
        self.cursor=(self.cursor+len(batch))%len(symbols)
        requested=list(dict.fromkeys(held+batch))
        results=await asyncio.gather(*[self.client.snapshot(contracts[s],liquid.get(s,{'quoteVolume':0})) for s in requested],return_exceptions=True)
        if self.stop.is_set():
            return
        candidates=[]
        errors=[]
        fresh=0
        for symbol,result in zip(requested,results):
            if isinstance(result,Exception):
                errors.append(f'{symbol}: {result}')
                with self.lock:
                    self.rows[symbol]=dict(symbol=symbol,price=None,score=0,signal='WAIT',reason=str(result),time=0,source='binance-public')
                continue
            current=int(time.time()*1000)
            if abs(self.client.now()-result.time)>self.c.stale_seconds*1000:
                errors.append(f'{symbol}: snapshot expired while awaiting batch')
                continue
            chosen=await self._process(result,current,execute=False)
            fresh+=1
            if chosen and chosen.strategy in self.approved:
                candidates.append((chosen.score,result,chosen))
        if not errors:  # Connectivity failure freezes all new entries for this cycle.
            for _,snapshot,signal in sorted(candidates,key=lambda x:-x[0]):
                result=self.broker.open(snapshot,signal,int(time.time()*1000),self.histories)
                with self.lock:
                    self.rows[signal.symbol]['reason']=result['reason']
                    if not result['approved']:
                        self.rows[signal.symbol]['signal']='REJECTED BY RISK ENGINE'
        self._update(scanner='DEGRADED — new entries paused' if errors else 'RUNNING',
                     connectivity='PARTIAL FAILURE' if errors else 'CONNECTED',eligible_markets=len(symbols),
                     scanned=fresh,last_scan=int(time.time()*1000) if fresh else 0,last_error='; '.join(errors))
        if errors:
            log.warning(json.dumps(dict(event='scan_errors',errors=errors)))

    async def run(self):
        while not self.stop.is_set():
            try:
                await self.cycle()
            except Exception as exc:
                if self.stop.is_set():
                    return
                message=f'{type(exc).__name__}: {exc}'
                self._update(scanner='PAUSED — market data unavailable',connectivity='ERROR',last_error=message,last_scan=0)
                log.error(json.dumps(dict(event='cycle_failed',error=message)))
                # Error artifacts do not rewrite the account ledger.
                self.store.artifact('last_error','error',dict(time=int(time.time()*1000),message=message))
            await asyncio.to_thread(self.stop.wait,self.c.scan_seconds)

    def shutdown(self):
        self.stop.set()
        self.client.stopped.set()
        if self.thread:
            self.thread.join(timeout=30)
            if self.thread.is_alive():
                raise RuntimeError('Scanner did not stop within 30 seconds; preserve database until process exits')
