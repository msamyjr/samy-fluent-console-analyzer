from dataclasses import dataclass, asdict
from decimal import Decimal, ROUND_FLOOR, ROUND_CEILING
import math


def positive(value):
    return isinstance(value, (int, float)) and math.isfinite(value) and value > 0


def quantize(value: float, step: float, up=False) -> float:
    if not positive(value) or not positive(step):
        raise ValueError('Invalid tick or quantity')
    return float((Decimal(str(value)) / Decimal(str(step))).to_integral_value(
        rounding=ROUND_CEILING if up else ROUND_FLOOR) * Decimal(str(step)))


@dataclass(frozen=True)
class Contract:
    symbol: str
    tick: float
    step: float
    min_qty: float
    min_notional: float
    max_qty: float = 1e12

    def __post_init__(self):
        if not self.symbol.isalnum() or not self.symbol.endswith('USDT'):
            raise ValueError('Invalid USDT contract')
        if not all(positive(x) for x in (self.tick, self.step, self.min_qty, self.min_notional, self.max_qty)):
            raise ValueError('Invalid exchange filters')
        if self.min_qty > self.max_qty:
            raise ValueError('Invalid quantity limits')


@dataclass(frozen=True)
class Candle:
    time: int
    open: float
    high: float
    low: float
    close: float
    volume: float

    def __post_init__(self):
        if type(self.time) is not int or self.time < 0:
            raise ValueError('Invalid timestamp')
        if not all(positive(x) for x in (self.open, self.high, self.low, self.close)):
            raise ValueError('Invalid candle price')
        if not (self.low <= min(self.open, self.close) <= max(self.open, self.close) <= self.high):
            raise ValueError('Invalid OHLC ordering')
        if not math.isfinite(self.volume) or self.volume < 0:
            raise ValueError('Invalid candle volume')


def validate_candles(candles, interval_ms, minimum=120):
    if len(candles) < minimum:
        raise ValueError('Insufficient historical candles')
    for previous, current in zip(candles, candles[1:]):
        if current.time - previous.time != interval_ms:
            raise ValueError('Missing, duplicate, or unordered candles')
    return candles


@dataclass
class Snapshot:
    contract: Contract
    time: int
    price: float
    bid: float
    ask: float
    quote_volume: float
    imbalance: float
    funding: float
    open_interest: float
    candles: dict
    returns: dict
    source: str = 'binance-public'
    oi_change: float | None = None
    next_funding_time: int = 0
    mark_price: float | None = None
    interval: str = '1m'

    def __post_init__(self):
        if type(self.time) is not int or self.time < 0:
            raise ValueError('Invalid snapshot timestamp')
        if not all(positive(x) for x in (self.price,self.bid,self.ask,self.open_interest)):
            raise ValueError('Invalid market price or open interest')
        if not self.bid <= self.price <= self.ask:
            raise ValueError('Invalid market bid/ask')
        if not math.isfinite(self.quote_volume) or self.quote_volume < 0:
            raise ValueError('Invalid quote volume')
        if not math.isfinite(self.funding) or not -1 < self.funding < 1:
            raise ValueError('Invalid funding rate')
        if not math.isfinite(self.imbalance) or abs(self.imbalance)>1:
            raise ValueError('Invalid order-book imbalance')
        if self.mark_price is not None and not positive(self.mark_price):
            raise ValueError('Invalid mark price')
        if self.oi_change is not None and not math.isfinite(self.oi_change):
            raise ValueError('Invalid open-interest change')
        if not all(math.isfinite(x) for x in self.returns.values()):
            raise ValueError('Invalid returns history')

    @property
    def spread_bps(self):
        return (self.ask - self.bid) / self.price * 10000


@dataclass(frozen=True)
class Signal:
    symbol: str
    side: int
    strategy: str
    stop: float
    target: float
    score: float
    reason: str
    regime: str
    volatility: float
    time: int

    def __post_init__(self):
        if self.side not in (-1, 1) or not all(positive(x) for x in (self.stop, self.target)):
            raise ValueError('Invalid signal')
        if not all(math.isfinite(x) for x in (self.score, self.volatility)) or self.volatility < 0:
            raise ValueError('Invalid signal feature')


@dataclass
class Position:
    id: str
    symbol: str
    side: int
    strategy: str
    qty: float
    entry: float
    stop: float
    target: float
    leverage: float
    margin: float
    risk: float
    opened: int
    last_time: int
    last_price: float
    entry_fee: float
    funding: float = 0.0
    liquidation: float = 0.0
    last_funding: int = 0

    def pnl(self, price=None):
        return self.side * self.qty * ((self.last_price if price is None else price) - self.entry)

    def dict(self):
        return asdict(self)
