"""Portable datasets; synthetic fixtures are permanently labeled as synthetic."""
from dataclasses import asdict
import hashlib
import json
import math
import random
from pathlib import Path
from .models import Candle, Contract, validate_candles
from .config import INTERVALS


def fingerprint(data):
    return hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def load_dataset(path):
    data=json.loads(Path(path).read_text(encoding='utf-8'))
    validate_dataset(data)
    return data


def validate_dataset(data):
    if data.get('source') not in ('synthetic-demo','binance-public','imported-historical'):
        raise ValueError('Dataset source must be explicitly identified')
    interval=INTERVALS[data['interval']]
    if not data['symbols']:
        raise ValueError('Empty dataset')
    for symbol, item in data['symbols'].items():
        contract=Contract(**item['contract'])
        if contract.symbol!=symbol:
            raise ValueError('Dataset contract mismatch')
        validate_candles([Candle(**x) for x in item['candles']],interval)
        times=[x['time'] for x in item.get('funding',[])]
        if times!=sorted(set(times)):
            raise ValueError('Duplicate or unordered funding events')
        for event in item.get('funding',[]):
            if not all(math.isfinite(event[k]) for k in ('rate','mark')) or event['mark']<=0 or not -1<event['rate']<1:
                raise ValueError('Invalid funding event')
    return data


def synthetic_dataset(count=2400,seed=17,start=1735689600000):
    rng=random.Random(seed)
    data=dict(schema=1,source='synthetic-demo',interval='1m',seed=seed,
              limitations=['Artificial OHLCV and funding; never evidence of market profitability'],symbols={})
    for n,symbol in enumerate(('DEMOAUSDT','DEMOBUSDT','DEMOCUSDT')):
        price=(100,40,10)[n]
        candles=[]
        for i in range(count):
            mode=(i//200+n)%5
            drift=(0.0004,-0.0004,0,0.0001,-0.0001)[mode]
            volatility=0.0015 if mode!=4 else 0.004
            change=rng.gauss(drift,volatility)
            close=price*math.exp(change)
            wick=abs(rng.gauss(0,volatility*0.5))
            c=Candle(start+i*60000,price,max(price,close)*(1+wick),min(price,close)*(1-wick),close,
                     5000*math.exp(rng.gauss(0,0.3)))
            candles.append(asdict(c))
            price=close
        funding=[dict(time=start+i*60000,rate=0.0001,mark=candles[i]['close']) for i in range(480,count,480)]
        data['symbols'][symbol]=dict(contract=asdict(Contract(symbol,0.0001,0.001,0.001,5)),candles=candles,funding=funding)
    return data


def save_dataset(path,data):
    validate_dataset(data)
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
