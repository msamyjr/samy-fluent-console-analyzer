@echo off
setlocal
cd /d "%~dp0"
py -3 -c "import sys; assert sys.version_info >= (3,11), 'Python 3.11 or newer is required'"
if errorlevel 1 (
    echo Install Python 3.11 or newer from python.org with the Windows Python launcher.
    pause
    exit /b 1
)
if not exist ".venv\Scripts\python.exe" py -3 -m venv .venv
if errorlevel 1 exit /b 1
".venv\Scripts\python.exe" -m pip install --requirement requirements.txt
if errorlevel 1 exit /b 1
".venv\Scripts\python.exe" -m unittest discover -s tests -v
if errorlevel 1 (
    echo Validation failed. See troubleshooting in README.md.
    pause
    exit /b 1
)
echo Installation complete. Run start_windows.bat or start_windows.bat --demo.
pause
endlocal
