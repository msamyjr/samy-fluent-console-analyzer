# SAMY AI FUTURES STUDIO v3 PRO

**Paper-only engineering preview · 75 USDT simulated capital · Python 3.11+**

A local Windows-oriented Python application for public Binance USDT-M perpetual market research, bounded multi-market scanning, explainable strategy candidates, evidence-gated autonomous paper positions, persistent risk controls, event-driven historical replay, and logistic-model research. The dark dashboard runs at `http://127.0.0.1:8765` on your own computer.

There is no production order client, private-key setting, withdrawal operation, or live execution mode. The exchange transport accepts only enumerated unsigned GET market-data endpoints.

## What was available

The supplied repository contained only `index.html` with the text `SAMY / Fluent Console Analyzer`. No v2 Python source, dashboard, tests, strategy history, or models were available. This application is a new implementation; compatibility with the missing v2 application cannot be established. The original file is retained.

This is a working **engineering preview**, not a fully validated trading release. Live Binance access first received proxy 403 and subsequently Binance HTTP 451 during validation, and Windows execution was unavailable. Synthetic replay and model reports are software checks, not evidence of profitable trading. See [validation](docs/VALIDATION.md) and the [feature/limitation matrix](docs/SCOPE.md).

## Windows 10/11 installation

1. Extract the ZIP into a writable folder.
2. Install Python 3.11 or newer from python.org, including the Windows Python launcher (`py`). Python 3.12.14 was tested on Linux.
3. Run `install_windows.bat`. It creates `.venv`, installs the intentionally empty dependency requirements, and runs the tests. No private keys or third-party Python packages are required.
4. Run `start_windows.bat --demo` to inspect the dashboard with clearly labeled artificial prices. Open the local address printed above in your browser.
5. Run `start_windows.bat` for public Binance data. Your location/network must permit `https://fapi.binance.com`. A failed connection pauses entries and appears in System health.

Demo and market accounts have separate directories: `data/demo` and `data/market`. Demo data cannot qualify a strategy. Do not copy a demo database into the market account.

Installation is not one click: Python installation and extraction are prerequisites. Windows compatibility is unconfirmed until the checklist below is executed on Windows.

### Linux/macOS / manual commands

Run commands from the extracted project root. Global options precede the subcommand.

```sh
python3 -m venv .venv
# Linux/macOS:
. .venv/bin/activate
# Windows Command Prompt instead:
# .venv\Scripts\activate.bat
python -m pip install --disable-pip-version-check -r requirements.txt
python -m unittest discover -s tests -v
python -m samy --config config/paper.json serve --demo
```

Stop the process with Ctrl+C. It retains account state. Start public-data mode with:

```sh
python -m samy --config config/paper.json serve
```

Only loopback is bound. Do not expose this development server to a LAN or the internet. UI controls use a per-process session token and local Host validation; no external scripts or fonts are loaded.

## Autonomous paper operation

The engine rotates through a bounded batch of dynamically discovered, currently trading USDT-margined perpetual contracts, after a 24-hour volume filter. Held symbols are monitored first on each cycle. Seven timeframes are requested by default; a market with missing histories, gaps, old quotes, or invalid filters is excluded. Adjust `scan_batch`, `concurrency`, `scan_seconds`, or the timeframe list in a copy of `config/paper.json` for your computer. Keep `1m` in the list. Default batch size 3 is intentionally a low-resource mode, not simultaneous coverage of every contract. Each row exposes freshness.

Signals are experimental rule candidates, with a heuristic rank, never an AI probability. The risk engine checks sizes, exchange filters, spread, liquidity, margin, cost reserves, volatility, correlation, account loss limits, and duplicate events. **No candidate opens automatically until its strategy has qualifying evidence and explicit local approval.** At release there are no approved strategies, so waiting is expected.

Evidence workflow:

```sh
python -m samy collect --symbols BTCUSDT ETHUSDT --interval 1m --start 2026-09-01T00:00:00Z --end 2026-10-01T00:00:00Z --output data/history.json
python -m samy evaluate data/history.json --strategy trend --output reports/trend-evaluation.json
python -m samy approve EVALUATION_ID_PRINTED_BY_EVALUATE
```

Use an appropriate historical period ending within the last 30 days when you run approval. The example dates above illustrate the format; update them to your research period. Approval requires a real/imported market dataset, at least 30 untouched-test trades, positive net test PnL, profit factor >=1.2, drawdown within the configured limit, and positive net PnL under doubled fees/slippage. The risk/cost configuration must match exactly. Approval expires when the evidence becomes over 30 days old. Nothing is automatically promoted. Failed/zero-trade evaluations remain rejected. Do not repeatedly tune against the same final test and call it untouched.

Approval is an engineering gate, not statistical proof of future expectancy. The currently listed contract universe and current filters introduce survivorship bias. Independent historical universe reconstruction, multiple-testing controls, longer samples, and forward paper evidence are still required for research confidence.

### Risk defaults

| Control | Default |
|---|---:|
| Starting paper capital | 75 USDT |
| Maximum positions | 2 |
| Planned risk per trade | 0.5% of equity (0.375 USDT initially) |
| Total planned risk | 1% (0.75 USDT initially) |
| Leverage | 2×; hard maximum 3× |
| Margin allocation cap | 50% of equity |
| Daily / weekly loss limits | 2% / 4% |
| Maximum drawdown | 8% |
| Loss streak cooldown | 3 losses / 60 minutes |
| Correlation rejection | Absolute aligned return correlation >=0.8 |
| Maximum spread | 10 basis points |
| Per-side taker fee / slippage assumption | 0.05% / 3 basis points |

Sizing rounds quantities **down** and reserves estimated round-trip fees, exit spread/slippage, and funding inside the planned stop-loss budget. It never raises leverage or quantity to reach exchange minimums. Hard ceilings allow configuration to become stricter, not to disable capital limits. Loss limits are measured against UTC day/week equity anchors and the persisted high-water mark.

Planned risk limits apply when admitting positions. They are not guaranteed realized-loss caps, and adverse moves can raise existing planned risk as a fraction of equity. No averaging, martingale, or leverage escalation exists. Fixed stops, targets, time exits, circuit exits, and estimated isolated liquidation are implemented. New entries pause on connectivity failure; missing quotes cannot support real exit fills, even in a simulator. Sampled paper quotes can miss intrabar moves.

**Emergency stop** latches in SQLite immediately. New entries stop. Holdings close at the next fresh observed executable-side quote. A market-data outage can delay closing. Restarting does not reset the stop. There is intentionally no UI reset. To begin a separate experiment, use a new data directory and preserve the old account; never delete records to hide losses. A loss-limit circuit is also persisted and requires a separate reviewed recovery decision.

## Backtesting

```sh
python -m samy demo-data --output data/demo-history.json --candles 2400 --seed 17
python -m samy backtest data/demo-history.json --strategy adaptive --output reports/demo-backtest.json
python -m samy backtest data/history.json --strategy trend --start 2026-09-15 --end 2026-10-01 --output reports/trend.json
```

The dataset defines symbols, a common base timeframe, candles, contract filters, and historical funding settlements. `--start` is inclusive and `--end` exclusive; ISO dates without a timezone are interpreted as UTC. Warmup candles precede the selected start. Each replay starts a fresh 75 USDT portfolio and never modifies the ongoing paper account. Reports are also registered in the local workspace database for dashboard viewing.

Entries use only prior closed-bar features and the next bar's open. Portfolio events are processed chronologically; opportunities at a timestamp are ranked together. Stop wins if both stop and target are touched. Gap-through stops use the adverse opening price, plus exit slippage. Crossing an approximate liquidation level uses a conservative adverse intrabar mark assumption. There is a fixed 2 bps historical spread assumption. Funding uses supplied settlement events; a missing funding array means **funding was not modeled**, not that it was zero in the real market. Reported Sharpe/Sortino are per bar; return-to-drawdown is not mislabeled as annualized Calmar.

The simulator assumes full fills, fixed fees/slippage, isolated margin, and a fixed maintenance-margin fraction. It reports unfunded isolated losses as an insurance deficit instead of pretending the account can settle unlimited negative balances. It does not reconstruct Binance's liquidation tiers, insurance fund, order queue, latency, or historical depth. See every report's assumptions. Models requiring multi-timeframe alignment do not signal in single-timeframe replay.

## AI research

```sh
python -m samy train data/history.json --horizon 5 --output reports/model.json
```

This really trains a standard-library L2 logistic regression on six causal features, with train-only scaling, a 60%/20%/20% chronological split grouped by timestamp, horizon-label purging at boundaries, three expanding walk-forward folds, and Platt calibration fitted only on validation observations. The final test is compared against train prevalence and a simple fixed momentum probability baseline. Reports include Brier score, log loss, accuracy, calibration bins, standardized coefficients, and feature-correlation warnings. Predictions concern positive **long** net return under an explicit cost hurdle; they do not estimate short trade confidence.

Model results remain research-only, even if their Brier score beats the baselines. Trading expectancy, independent replication, and adequate statistical power have not been established. No inference model drives paper execution, no retraining scheduler or auto-promotion exists, and no neural network is represented as trained. Reports from artificial datasets retain their synthetic label.

## Storage, audit, export, and recovery

- `data/market/paper.sqlite`: atomic account state, append-only executed risk decisions and position/funding events, research artifacts. SQLite WAL with FULL synchronization.
- `data/market/system.log`: structured JSON payloads for service errors.
- Dashboard decision rows expose rule-level WAIT/research rejection explanations; the SQLite trade audit records decisions that reach the risk engine.
- One server process owns a data directory. A platform-specific OS lock releases on exit/crash. Research commands may register artifacts while the server runs; they do not write its account state.
- Export the ledger with the dashboard link. Backtest and model JSON files contain reproducibility metadata and configuration hashes.
- Create a consistent backup: `python -m samy backup backups/account-01.sqlite` (choose a new output path).
- Restore only while the server is stopped: preserve the old directory first, then place a verified backup as `paper.sqlite` in a **new** data directory. Never mix old WAL/SHM files with a restored main database. The database is integrity-checked on open. Retain the configuration used for open positions; changing risk configuration with holdings is rejected.

No secret values are needed or stored. Do not add exchange API keys to this project.

## Troubleshooting

- **`py` missing:** reinstall Python with the Windows launcher, or create `.venv` with a known Python 3.11+ executable.
- **Port 8765 busy:** stop your other instance, or `python -m samy serve --port 8766`. Do not stop unrelated processes.
- **Proxy 403 / HTTP 451 / regional restriction:** permit `fapi.binance.com` in the cloud environment settings when appropriate, and verify access from your region. Configuration-draft saves do not apply network changes. Do not bypass geographic restrictions. Use `serve --demo` for offline engineering checks.
- **No trades:** inspect the explanation column. No approved evidence, inadequate history, minimum notional, spread, correlation, daily limits, or margin can correctly lead to WAIT/rejection.
- **Missing candles or stale prices:** the market is excluded, not interpolated. Check clock synchronization, connectivity, rate limits, and the selected history.
- **Stop latched:** restart preserves it. Use a separate account directory for an independent experiment; do not erase the audit.
- **Database corruption:** stop the server, preserve the original files, and restore a consistent backup to a new directory. Never silently create an empty account over a damaged database.
- **Different experiment/account:** pass `--data-dir PATH` before the subcommand on every related command. Reports and approvals belong to that workspace.

## Windows verification checklist (not yet executed)

Run both batch files on Windows 10/11 in a path containing spaces. Confirm all unit tests pass, the dashboard opens in Edge/Chrome, every tab and filter works, demo labels are visible, a second server on the same data directory is rejected, emergency stop survives restart, and backup restoration preserves the account. Then verify public Futures metadata/candles from the user's permitted network. Validate on Windows before calling this a Windows-tested release.

Further engineering context: [architecture](docs/ARCHITECTURE.md), [scope and next improvements](docs/SCOPE.md), [validation](docs/VALIDATION.md).


## Optional browser checks and packaging

The application and unit suite need no third-party packages. Optional browser regression checks use the pinned `requirements-browser.txt` plus a Chromium installation (`python -m playwright install chromium` in a development environment). Start a **disposable demo account**, then run `python scripts/browser_smoke.py --port 8765`. This test deliberately latches emergency stop. On the validated Linux host an existing Chromium executable was selected with `--browser-executable /usr/bin/chromium`. Screenshots and machine-readable outcomes are retained under `docs/evidence` for this release.

Package the allowlisted source/docs/tests/evidence with `python scripts/package_release.py`. It excludes account databases, virtual environments, Git metadata, caches, and runtime logs. The archive includes a per-file SHA-256 manifest and has a separate ZIP checksum. No pre-populated trading account is distributed.
