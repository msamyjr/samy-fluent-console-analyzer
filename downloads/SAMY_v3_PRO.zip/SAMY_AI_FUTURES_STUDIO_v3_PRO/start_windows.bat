@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Run install_windows.bat first. Python 3.11 or newer is required.
    pause
    exit /b 1
)
echo SAMY AI FUTURES STUDIO v3 PRO - PAPER ONLY
echo Open http://127.0.0.1:8765 in your browser after startup.
echo For offline demo: start_windows.bat --demo
if "%~1"=="--demo" (
    ".venv\Scripts\python.exe" -m samy --config config\paper.json --data-dir data\demo serve --demo
) else (
    ".venv\Scripts\python.exe" -m samy --config config\paper.json --data-dir data\market serve
)
if errorlevel 1 pause
endlocal
