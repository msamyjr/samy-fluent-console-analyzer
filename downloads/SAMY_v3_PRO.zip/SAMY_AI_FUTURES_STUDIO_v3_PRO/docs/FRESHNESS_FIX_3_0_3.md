# Version 3.0.3: price freshness, analysis freshness and unavailable data

## Observed defects

A user screenshot showed old candidates ranked above newer observations, almost every row marked STALE, and an unavailable funding value rendered as NaN%. The original scanner refreshed only three full seven-timeframe snapshots per analysis cycle. With 118 eligible markets, a full rotation could take about 20 minutes plus request time. One shared timestamp conflated price updates, indicator analysis and funding observations. A 30-second cycle could also outlive the 20-second quote cutoff even immediately after a batch.

## Corrected behavior

- One independent unsigned public all-symbol `/fapi/v1/ticker/bookTicker` request targets refreshes about every five seconds after discovery. It refreshes display prices for metadata-verified eligible Futures contracts. Actual cadence depends on latency and rate limits; it is not a streaming feed.
- This quote lane does not wait for the bounded candle-analysis semaphore. It shares the same conservative 600-weight/minute limiter, cancellation, cache lock, retries and cross-request Retry-After cooldown. A conservative weight of 10 is reserved for an all-symbol quote request. It does not bypass exchange limits.
- The original exchange quote event timestamp is retained. Missing, invalid and future quotes are rejected. A successful HTTP response does not stamp old event data as fresh. Older/duplicate responses cannot overwrite a newer event.
- Full multi-timeframe analysis remains bounded and rotating. Depth/funding/OI/candle validations and the 20-second snapshot cutoff remain in place. A new price alone cannot approve an entry, mark/close a paper position, or renew an expired strategy analysis.
- The table separately displays PRICE DATA and ANALYSIS. Analysis is based on the last closed one-minute candle, with the same 90-second maximum signal age used by entry validation. Expired analysis is shown as WAIT with zero displayed opportunity score. The previous label/reason remain in detail; audit decisions are preserved.
- Funding is labeled LAST FUNDING; cached observations are identified. Unknown prices, spread and funding render as a dash, never zero, NaN%, or undefined.
- Analysis failures preserve any independently valid quote while retaining the analysis rejection reason. Dashboard health reports current quotes, current analyses, pending analyses, per-market errors and the app version.
- Live paper position management continues to require its full validated snapshot and funding/mark inputs; the display-only quote lane does not change that cadence or relax risk gates. No strategy or model was approved by this repair.

## Validation and remaining limits

The test suite covers public GET filtering, malformed/absent/old/future/duplicate quotes, out-of-order response protection, independent quote updates while analysis waits, semaphore independence, non-renewal of old signals, heartbeat/freshness distinction, failure explanations, shared rate-limit cooldown and cancellation. Real Chromium checks cover missing data without NaN, separate price/analysis columns, WAIT on expired analysis, health counts and mobile width, plus the existing dashboard smoke suite. See the actual result JSON files in `docs/evidence`.

The new endpoint could not be validated against live Binance from the cloud execution environment (regional access remains restricted); its parser/transport and UI behavior were validated with explicit fixtures. Native Windows 3.0.3 validation is pending. It remains normal for ANALYSIS to show pending/expired while PRICE DATA is current, and for an actually stale quote to remain STALE. Fast price display is not continuous all-market strategy analysis or high-frequency position monitoring.

## Updating an existing Windows installation

Stop the running server with Ctrl+C. Extract the new archive separately, then copy only its `samy` and `tests` folders into the existing application folder and replace matching files. This code/test-only update preserves the existing `data`, `reports`, custom `config`, and `.venv` directories. Run `install_windows.bat` in the existing folder and continue only if all tests finish OK. Confirm `.venv\Scripts\python.exe -m samy --version` prints 3.0.3, then start the application normally. The dashboard banner also shows the version.

Do not delete account databases or reset emergency stops as an update shortcut. If updating into a completely new folder instead, the previous account remains in the old folder; follow the documented stopped-server backup/restore procedure before migrating it.
