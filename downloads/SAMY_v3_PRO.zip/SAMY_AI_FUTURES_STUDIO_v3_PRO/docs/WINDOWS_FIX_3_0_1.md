# Version 3.0.1: Windows resource handling

The user executed the original installer on Windows with Python 3.15. Of 75 tests, 73 passed and two errored. Installation correctly stopped; the tests were not bypassed.

## Confirmed defects and fixes

1. `test_sqlite_backup_recovery`: `sqlite3.Connection` used as a context manager commits or rolls back, but does **not** close. The backup connection therefore retained a Windows file handle, and temporary-directory cleanup failed with WinError 32. `Store.backup` now uses `contextlib.closing`, guaranteeing destination closure on success and on exceptions.
2. `test_process_lock`: the constructor read the first byte of an already locked file before its exception handler. Windows byte-range locking can reject that read with PermissionError. The constructor now uses file metadata for initialization, acquires the lock at offset zero, normalizes initialization/acquisition errors to an actionable RuntimeError, and closes the descriptor on failure.

Six additional regressions cover backup closure after success and failure, no protected-byte reads, cleanup after initialization errors, permission-denied opening, simulated Windows backend contention, and a native subprocess acquiring/rejecting/reacquiring the OS lock. The original 75 tests remain enabled. Windows-specific backend simulation on Linux is explicitly **not** native Windows verification.

## Update on the user's Windows computer

1. Stop any running SAMY window.
2. Download the updated 3.0.1 archive and extract it into a **new** folder. Do not run the old 3.0.0 installer or overwrite an existing account directory.
3. In the new folder run `install_windows.bat`. Python is already installed; reinstalling it is not required for these fixes. The expected suite now contains 81 tests. Continue only if the suite finishes `OK`.
4. Run `start_windows.bat --demo` from Command Prompt in that folder, then open the local dashboard address printed by the launcher.
5. Preserve any old `data` folder. Do not delete account data to fix installation tests. A fresh demo uses its own new account.

The repaired suite was validated in the available Linux environment; the repaired Windows installer, real Windows file-lock semantics and Python 3.15 runtime still require the user's rerun. Public Binance HTTP 451 and the paper-only research limitations are unchanged.
