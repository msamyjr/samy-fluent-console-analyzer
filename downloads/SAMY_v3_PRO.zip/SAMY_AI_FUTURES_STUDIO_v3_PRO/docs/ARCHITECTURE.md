# Architecture and invariants

```
Public GET Futures data -> validated closed candles -> causal features
    -> experimental strategies -> evidence registry -> ranked candidates
    -> final risk approval -> local paper ledger -> SQLite transaction
                             -> dashboard / JSON audit
Historical dataset -> chronological portfolio replay -> metrics / cost stress
Historical dataset -> purged chronological model research -> inactive reports
```

No transport connects the paper broker to an exchange. `data.py` has the only exchange HTTP client, fixed to public USDT-M market-data routes. `server.py` serves loopback assets, read-only state/export, and an authenticated local emergency-stop mutation. It cannot submit trades through an HTTP order route.

| Module | Responsibility |
|---|---|
| `config.py` | Validated defaults, hard risk ceilings, timeframe definitions |
| `models.py` | Candle/contract validation, Decimal-based tick/quantity rounding |
| `data.py` | GET allowlist, weighted throttle, retries, bounded cache, clock synchronization, dynamic discovery and snapshots |
| `indicators.py` | Causal EMA/SMA/VWAP/RSI/MACD/ATR/bands/ROC/OBV, return correlation, structure boundaries, regime heuristics |
| `strategies.py` | Ten explicit research candidates, stop/target construction and explanations |
| `risk.py` | Liquidity/freshness/correlation/margin checks, fee-aware sizing, loss-budget gates |
| `broker.py` | LONG/SHORT local ledger, costs, funding, isolated liquidation assumptions, duplicate protection and persistent circuits |
| `store.py` | Transactional snapshot plus append-only audit, artifacts, backup and integrity checks |
| `dataset.py` | Source-labeled portable datasets and reproducible synthetic fixtures |
| `backtest.py` | Shared portfolio/risk replay with prior-bar signals, cost stress and qualification |
| `research.py` | Actual logistic fitting, calibration, purged splits, walk-forward and baselines |
| `service.py` | Bounded rotating discovery/scanning, holdings monitoring, ranking and approval checks |
| `server.py`, `web/` | Responsive local terminal, safe text rendering and account views |
| `__main__.py` | CLI, workspace selection, process lock, report registry and Windows-compatible startup |

## Account conventions

Wallet cash includes settled PnL minus fees and funding. Initial margin is reserved, not subtracted a second time. Equity is wallet cash plus marked isolated-position PnL, capped below by each position's isolated collateral assumption. Free margin is nonnegative equity minus reserved margin. The dashboard shows fees, funding, closed-trade net results, and any unfunded isolated deficit separately.

Every opening transaction charges its entry fee once. Every close settles directional PnL minus its exit fee once. Funding events are keyed by settlement timestamp and applied only to positions already open at that time. Per-trade net PnL includes both fees and paid funding. On a fully closed account, the sum of trade net PnL reconciles to wallet cash minus initial capital. Insurance deficits are explicit simulator assumptions, not exchange-verified protection.

A single reentrant broker lock protects check-and-open/close and persisted state. State mutations are committed with their events before replacing the in-memory snapshot. SQLite uses WAL and FULL synchronization. The server has an OS-level process lock; another server or offline stop command cannot independently overwrite its account state. SQLite serializes report-artifact writes from research commands.

## Candidate policy

All ten strategies use explicit fixed 2-ATR/minimum-distance stop construction, a 2R target, cost-aware sizing, maximum holding time, stop/target/circuit invalidation, and leverage caps. Regime and entry differences are declared in the strategy registry. They are hypotheses, not ten independently proven edges. The scanner displays candidates even without evidence, with a research-only explanation. It executes only approved strategies through the shared risk engine. Sizing validity alone never establishes expected edge.

A persisted kill switch prevents entries and exits at the next fresh quote. Loss circuits and consecutive-loss cooldown survive restart. Missing data pauses new positions and never causes a fabricated exit fill. Risk configuration changes with existing holdings require restoring the previous configuration first.

## Dataset example

A JSON object has `schema: 1`, `source` (`binance-public`, `imported-historical`, or `synthetic-demo`), a common `interval`, and `symbols`. Each symbol contains `contract` (`symbol`, `tick`, `step`, `min_qty`, `min_notional`, `max_qty`), `candles` (`time` in UTC milliseconds, `open`, `high`, `low`, `close`, `volume`), and optional `funding` events (`time`, `rate`, `mark`). Candles must be ordered, unique, contiguous, and valid. Local imports must identify their actual provenance; the software cannot independently authenticate an arbitrary JSON file's market origin.

## Resource and concurrency assumptions

Default scan batch/concurrency are 3/3 with a 30-second cycle. A conservative 600-weight-per-minute local throttle is used, with bounded retry attempts and respect for Retry-After. Long retry-after responses fail closed rather than retrying early. Snapshot candles are cached briefly; the cache is capped at 1024 request keys. Each enabled timeframe requests 120 closed candles. REST pooling is via bounded worker threads coordinated by asyncio. No WebSocket or incremental candle engine is claimed. Shutdown cancels queued requests and interruptible backoff, while allowing an in-flight HTTP timeout to finish.
