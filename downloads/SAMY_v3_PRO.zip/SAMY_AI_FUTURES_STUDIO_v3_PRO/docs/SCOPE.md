# Implemented scope and remaining work

This is an engineering preview built from a one-line static repository, not an upgrade of inspected v2 Python code. The complete master-prompt scope is larger than this release. The following distinctions are deliberate and testable.

| Area | Implemented | Remaining / limitation |
|---|---|---|
| Exchange safety | Unsigned public GET allowlist, no private credentials, no order client | No testnet execution adapter (not needed for local paper fills) |
| Futures discovery | Dynamic USDT perpetual/status/margin/filter checks, 24h volume filter | Real exchange responses not verified because public endpoint returned HTTP 451 after initial proxy 403 |
| Data | OHLCV, book depth/spread/imbalance, funding, OI and observed OI change, clock sync, stale rejection | No liquidation stream, historical OI series, WebSockets, incremental candles or historical universe reconstruction |
| Scanner | Seven configured timeframes; bounded concurrency; rotating liquid universe; explanations and freshness | Display quotes refresh separately; full analysis still rotates in bounded batches. A current quote does not renew expired analysis. No continuous all-market inference or faster position-monitoring claim |
| Indicators | EMA/SMA/VWAP, rolling RSI, MACD, ATR, Bollinger/Keltner, ROC, OBV, relative volume, causal range levels, realized volatility | Directional index is a rolling heuristic, **not Wilder ADX**. No Supertrend, Ichimoku, Stochastic RSI, volume profile, divergence or validated structural-pattern library |
| Strategy candidates | Ten executable rules with regime conditions, stops, targets and shared risk/cost logic | No strategy qualified on real market data. No claim of independent strategy value or profitable edge |
| Paper engine | Ranked multi-symbol entries, max two LONG/SHORT positions, deduplication, fees/funding, stops/targets/time/circuit exits, restart | Approval required. Demo never auto-trades. Quote sampling can miss intrabar events; no partial fills, trailing/break-even/partial-profit exits |
| Risk | 75 USDT initial account; <=0.5%/1% planned risk; conservative margin/leverage; rounded filters; correlation, liquidity, stale data, cooldown/loss/drawdown/kill controls | Estimated liquidation uses fixed maintenance margin; no Binance tier schedule. Limits are planned loss budgets, not guarantees |
| Historical replay | Portfolio chronology, next-open fills, stop-first ambiguity, gap handling, fixed spread, fees/slippage, supplied funding, JSON reports and doubled-cost stress | Common dataset base interval; no multi-timeframe historical alignment input, historical depth, queue or latency model, parameter grid or full sensitivity sweep |
| Analytics | Equity, drawdown, closed trades, exposure fraction, turnover, fees/funding, win/loss, expectancy, per-bar ratios, per-symbol sums | No full monthly/regime attribution, statistical confidence intervals, annualized Calmar or specialized tail-risk report |
| AI | Actual L2 logistic regression, causal features, chronological purged train/calibration/test, expanding folds, diagnostics and two simple baselines | Long-target research only. Inference disabled; no RF/XGBoost/deep learning, calibrated short target, ablation suite or statistically validated model promotion |
| Governance | Qualifying real-data evidence, untouched-test count/return/PF/drawdown gate, cost stress, manual approval, expiration/config match | No automatic strategy search/retraining, alpha significance/multiple-comparison correction, or forward-performance promotion |
| Dashboard | Responsive terminal, real account state, freshness/errors, markets/filter/details, positions, equity, research/backtest reports, audit export, kill switch | Research runs via CLI; backtest form prepares a command rather than launching a background research job |
| Storage | SQLite WAL/FULL transactions, audit, models/evaluations/backtests, snapshots and backup | No external database adapter, automated retention or full candle warehouse |
| Validation | Unit/integration/regression, randomized sizing properties, race/restart/recovery tests, desktop/mobile Chromium checks | Live exchange and repaired Windows runtime checks not verified; no stress certification or soak test |

## Recommended next improvements, in order

1. Supply the missing v2 application if compatibility matters. Compare behavior before migrating real v2 histories or settings.
2. Apply network permission for `fapi.binance.com` from a supported location and perform public exchange contract/schema integration tests. Archive representative responses without credentials.
3. Execute the documented Windows checklist, including paths with spaces, browser interactions, OS process locking, restart and backup recovery.
4. Collect a provenance-controlled historical universe including delistings, historically applicable contract filters, funding completeness, and finer-grained execution data. Add survivorship and liquidity controls before relying on results.
5. Add real data qualification and longer untouched/forward paper observation. Use block-bootstrap uncertainty, multiple-testing controls and parameter sensitivity; most candidates may correctly remain rejected.
6. Add incremental REST updates/WebSocket mark/book monitoring and priority risk polling, with reconnection and reconciliation tests. Separate scanner/research CPU work further as the universe grows.
7. Add historical multi-timeframe replay, funding-completeness validation, more faithful liquidation tiers, latency/partial fills and dedicated exit-technique experiments.
8. Expand model candidates and feature-ablation tests only when a dataset and baseline justify the complexity. Maintain explicit human-reviewed promotion; never turn the transport into production execution.

No expected financial performance is promised by this release. The bundled experiments use artificial data and cannot qualify strategies or models for deployment.
