# Version 3.0.2: historical execution costs and rare-event diagnostics

## Confirmed execution-cost defect

The previous historical simulator declared a fixed two-basis-point spread. Entry snapshots applied the adverse one-basis-point half-spread, but reference-price exits applied slippage without the exit half-spread. Consequently historical exit costs were understated. This was found during a review against real user-provided data. It does not explain away an otherwise losing strategy and is not a reason to approve one.

The repaired replay explicitly applies one adverse basis point on entry and on exit, followed by the configured per-side slippage and taker fees. Both LONG and SHORT positions, stop/target exits and end-of-test closure share this cost path. Live paper monitoring already passes observed executable bid/ask quotes, so its broker uses zero additional assumed half-spread and avoids charging spread twice. Backtest outputs identify their execution model and spread assumption.

## Evidence and account safety

Evaluations created under the old or missing execution-cost model cannot qualify a strategy or remain active through the approval registry. Rerun evaluation under 3.0.2. No risk budget, leverage cap, daily/weekly loss limit, cooldown, correlation limit or emergency stop was relaxed. A rejected strategy stays rejected; no model is promoted.

The fitted logistic estimator and its thresholds were not tuned against the supplied test period. Model score reports now expose positive counts/rate, mean probability, an always-negative accuracy baseline, positive prediction count and precision/recall at 0.5. The `beats_baselines` field still represents a numeric Brier comparison only; it is not a statistical-significance finding or trading permission.

## Validation and limitations

New regressions exercise adverse LONG and SHORT exit fills, unchanged executable-side live fills, two-sided end-of-replay costs, invalid cost inputs, rejection of stale execution-cost evidence and rare-event accuracy interpretation. The full suite executes 87 tests. See `docs/evidence/test-results.json` for actual outcomes. Native Windows revalidation of 3.0.2 is pending; the Windows resource repairs from 3.0.1 remain included.

The fixed historical spread is still an assumption. Historical depth, queueing, partial fills, per-tier maintenance margin, and exactly contemporaneous bid/ask data are not reconstructed. Source-provided OHLC prices are reference prices; they are not asserted to be historical midquotes.

User-provided market files, models, evaluation reports and derived audit data are kept outside the release payload. Bundled reports use only the deterministic synthetic fixture, are regenerated under the corrected historical cost model, and cannot qualify a strategy.
