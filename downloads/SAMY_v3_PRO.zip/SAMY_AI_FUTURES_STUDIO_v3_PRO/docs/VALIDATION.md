# Development and validation report

Validation date: 20 October 2026. This report distinguishes executed software checks from unverified exchange/Windows behavior. It does not certify financial performance or completion of the entire master-prompt scope.

## Audit

The available checkout at original commit `c4f039442d50bc2c2d45440ae486039fa7593099` contained only the 31-byte `index.html`. No v2 Python sources, dependencies, tests, model artifacts, or account database were available. The original file remains unchanged. This release adds a new modular application, test suite, configuration, documentation and packaging tools. No v2 regression suite could be rerun.

## Windows defect report and 3.0.1 repair

The user ran the original installer on Windows/Python 3.15: 73 tests passed and two errored. The failures exposed an unclosed SQLite backup connection and a protected-byte read before the lock constructor's exception handler. Both defects are repaired in 3.0.1, with six additional resource/locking regressions. The full repaired suite passes on Linux; native Windows verification of the repair is pending. See [Windows fix details](WINDOWS_FIX_3_0_1.md).

## Historical-cost repair in 3.0.2

A subsequent data/research audit reproduced the supplied reports and found that the historical fixed spread was applied only on entry. Version 3.0.2 adds the adverse exit half-spread, records the execution model, rejects old-model approvals, and adds explicit rare-class diagnostics to model reports. No fitting parameters or risk limits were optimized against the supplied holdout. User data and audit results are outside the release. See [3.0.2 repair details](COST_FIX_3_0_2.md).

## Executed automated checks

The 3.0.2 isolated Python 3.12.14 environment executed **87 tests: 87 passed, 0 failures, 0 errors, 0 skipped, 0 expected failures, 0 unexpected successes**. Exact timing, runtime and outcomes are in [test-results.json](evidence/test-results.json); individual test names/results are in [unittest.log](evidence/unittest.log).

Coverage includes:

- Public GET endpoint restrictions, private parameter rejection, Futures metadata filtering, retries, cache, clock skew, bounded outage handling, long Retry-After rejection and cancellation.
- Missing/duplicate/out-of-order candles, invalid OHLCV and nonfinite market values; flat and volatility-spike regimes; return correlation aligned by timestamps.
- LONG/SHORT sizing, fee/funding reserves, minimum notional, no leverage escalation, loss limits, drawdown, stale quotes/signals, spread, liquidity, correlation, margin exhaustion, targets below costs and 300 deterministic randomized sizing cases.
- Two simultaneous symbols, third-position rejection, duplicate events across close/restart, concurrent open attempts, funding credits/debits/deduplication, extreme funding, stop-first ambiguity, stop gaps, take-profit, liquidation/insurance assumptions and time exits.
- Ledger reconciliation, rejected negative prices, atomic rollback on a simulated disk failure, SQLite backup/recovery, configuration changes with open positions, restart, persisted emergency stop and cooldown.
- Reproducible portfolio replay, future-data perturbation regression, real logistic fitting with purged boundaries and walk-forward, calibration-bin accounting, synthetic evidence rejection and evidence governance.
- HTTP state/assets/export, no live/file-traversal routes, token-protected emergency stop, Host validation, process locking, network outage protection and a ranked autonomous multi-symbol cycle with explicitly mocked data and evaluation evidence.

The randomized cases use Python's seeded standard-library RNG; no third-party property-testing framework is claimed. Mock exchange responses are software fixtures and are not claimed as real live integration evidence.

## Browser and functional validation

For the initial 3.0.0 release, Chromium 154.0.8037.57 rendered the running local demo application. These retained browser checks cover unchanged frontend assets; they were not rerun for the resource-only 3.0.1 repair. Executed checks passed for desktop (1440px) and mobile (390px) views, six navigation tabs, symbol filtering, feature detail, backtest command preparation, and the emergency stop including persistent account-state confirmation. No JavaScript page errors occurred; mobile document width fit the viewport. Evidence: [browser-results.json](evidence/browser-results.json), [desktop screenshot](evidence/dashboard-desktop.png), [mobile screenshot](evidence/dashboard-mobile.png). The stop check uses a disposable account and deliberately latches it.

The standard-library runtime was installed into a clean `.venv`; `requirements.txt` has no external runtime dependencies. Python compilation and JavaScript syntax checks succeeded. These are supplemental checks, not substitutes for the executed tests and browser requests.

## Actual research runs, artificial data only

The release includes a reproducible three-symbol, 1,000-candle-per-symbol synthetic dataset, seed 17. It contains artificial bullish, bearish, sideways and high-volatility segments and artificial funding settlements. It is permanently labeled `synthetic-demo`.

[synthetic-backtest.json](evidence/synthetic-backtest.json) is the actual full-period adaptive replay report. It executed 55 closed paper trades and accounted for 2.042044734201461 USDT of fees. Its final net PnL was +2.155996934978589 USDT under the documented simulated fill assumptions. Funding events were available, but this run incurred zero funding charges because its position timing did not cross those events. Funding debit/credit behavior is separately exercised by the automated tests. The fixture numbers are implementation diagnostics, **not historical exchange performance or evidence of an edge**. Earlier development runs used a different conservative stop-fill approximation; the final report uses stop-first intrabar execution and adverse-opening fills for gaps as documented.

[synthetic-model.json](evidence/synthetic-model.json) contains the actually trained logistic candidate: 525 untouched-test observations, Brier score 0.19858100820810212, log loss 0.5842394164873572 and classification accuracy 0.7047619047619048. Calibration, baseline scores, split boundaries and standardized weights are in the report. It beats the two simple probability baselines on this artificial split; it remains **inactive** and says nothing about real-market net trading return.

All ten rule candidates are also evaluated on the same source-labeled synthetic dataset with chronological validation/test separation and doubled-cost stress. Their individual `candidate-*.json` files and [summary](evidence/candidate-summary.json) contain the actual outcomes, including zero-trade outcomes. Synthetic evidence is always ineligible; no candidate is approved by these reports. This is a functional evaluation pipeline, not a search for claims of profitable returns.

## External blockers and unexecuted checks

- Initial direct public Futures requests received proxy tunnel HTTP 403. After the required hostname was saved in the environment draft, a subsequent application-level check received **Binance HTTP 451**. There is a location/access restriction; no exchange schema/data response was validated. See [live-connectivity.json](evidence/live-connectivity.json). The running app correctly paused, reported freshness false, left equity at 75 USDT, and opened no positions. No regional restriction bypass was attempted.
- Full live public discovery, seven-timeframe snapshots, data quality against the exchange, long-running connection recovery and real-data historical collection remain **unverified**. Mock tests cannot establish these.
- The original Windows/Python 3.15 installer was executed by the user and exposed the two documented defects. Native Windows revalidation of 3.0.2, including locking/backup cleanup and Windows browser integration, remains **unverified**. The README provides the checklist; Linux passes do not establish Windows compatibility.
- No real-market trained model, independently validated strategy edge, live exchange performance, prolonged forward-paper test, or profit guarantee exists.
- Advanced features explicitly deferred in [SCOPE.md](SCOPE.md) are not silently considered implemented. This preview does not satisfy every full-release acceptance criterion in the supplied master prompt.

## Reusable cloud setup

The environment draft contains the necessary `fapi.binance.com` domain, a tested standard-library virtual-environment install script, and updated `start_skill` instructions for the Python app, offline validation, market-data failure handling, account separation and persistent safety state. The old static-server startup instructions were replaced. The user must review/save and publish the environment through settings to activate reusable configuration/snapshots. Draft persistence does not prove publication or successful fresh-task restoration. An allowlist change alone does not resolve Binance's HTTP 451 restriction.

## Release contents and integrity

The ZIP contains complete source, static dashboard assets, example settings, deterministic synthetic data, unit/integration tests, Windows scripts, the user guide, architecture/scope/validation documentation, actual research reports and browser evidence. A per-file SHA-256 manifest is inside the ZIP; the archive has a separate checksum. No runtime database, credentials, virtual environment, browser binary, Git metadata or user account state is included. For the initial release, extracted replay reproduced the recorded metrics exactly. For 3.0.2, the package was extracted into a path containing spaces, every file hash and ZIP CRC was verified, the historical-cost regressions and prior Windows-resource regressions passed, and its CLI/demo server returned three labeled synthetic markets with 75 USDT before a clean Ctrl+C shutdown. See [package-checks.json](evidence/package-checks.json). The 3.0.2 archive includes the corrected historical cost model, Windows resource fixes, regression tests and updated validation records. Its current extraction checks are recorded in package-checks.json; full native Windows revalidation remains pending.
