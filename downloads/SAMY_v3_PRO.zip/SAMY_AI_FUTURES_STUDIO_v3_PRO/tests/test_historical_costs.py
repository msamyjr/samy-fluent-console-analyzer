"""Execution-cost regressions: historical reference quotes vs live bid/ask."""
from contextlib import closing
from dataclasses import replace
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from samy.backtest import run_backtest,HISTORICAL_SPREAD_BPS
from samy.broker import PaperBroker
from samy.config import Config
from samy.dataset import synthetic_dataset
from helpers import snapshot,signal,NOW


class HistoricalCostTests(unittest.TestCase):
    def test_exit_spread_worsens_long_and_short_fills(self):
        from samy.store import Store
        for side in (1,-1):
            with self.subTest(side=side),tempfile.TemporaryDirectory() as temp:
                results=[]
                for spread in (0,1):
                    with closing(Store(Path(temp)/f'{spread}.sqlite')) as store:
                        broker=PaperBroker(Config(),store,exit_half_spread_bps=spread)
                        approval=broker.open(snapshot(),signal(side=side),NOW,{})
                        self.assertTrue(approval['approved'])
                        broker.close_observed('TESTAUSDT',100,NOW+1000,'cost audit')
                        trade=broker.state['trades'][0]
                        expected=100*(1-side*spread/10000)*(1-side*Config().slippage_bps/10000)
                        self.assertAlmostEqual(trade['exit'],expected,places=10)
                        self.assertAlmostEqual(broker.view()['equity']-75,trade['net_pnl'])
                        results.append(trade)
                self.assertLess(results[1]['net_pnl'],results[0]['net_pnl'])

    def test_live_executable_quote_does_not_get_a_second_spread(self):
        from samy.store import Store
        with tempfile.TemporaryDirectory() as temp,closing(Store(Path(temp)/'live.sqlite')) as store:
            broker=PaperBroker(Config(),store)
            broker.open(snapshot(),signal(),NOW,{})
            bid=99.99
            broker.close_observed('TESTAUSDT',bid,NOW+1000,'observed live bid')
            self.assertAlmostEqual(broker.state['trades'][0]['exit'],bid*(1-Config().slippage_bps/10000))

    def test_replay_applies_declared_half_spread_on_both_legs(self):
        data=synthetic_dataset(122)
        data['symbols']={s:item for s,item in data['symbols'].items() if s=='DEMOAUSDT'}
        item=data['symbols']['DEMOAUSDT']
        item['contract']['tick']=.000001
        for c in item['candles']:
            c.update(open=100.0,high=100.0,low=100.0,close=100.0)
        c=Config()
        def fixed(snap,strategy):
            return replace(signal('DEMOAUSDT',now=snap.time),stop=99,target=102)
        with patch('samy.backtest.generate',side_effect=fixed):
            report=run_backtest(data,c,'trend')
        self.assertEqual(report['metrics']['trades'],1)
        t=report['trades'][0]
        self.assertEqual(t['reason'],'end of backtest')
        self.assertAlmostEqual(t['exit'],100*(1-HISTORICAL_SPREAD_BPS/20000)*(1-c.slippage_bps/10000))
        self.assertAlmostEqual(t['entry'],100*(1+HISTORICAL_SPREAD_BPS/20000)*(1+c.slippage_bps/10000),places=5)
        self.assertEqual(report['historical_spread_bps'],2)
        self.assertAlmostEqual(report['metrics']['net_pnl'],t['net_pnl'])

    def test_invalid_exit_costs_are_rejected(self):
        for value in (-1,10000,float('nan'),float('inf'),'one'):
            with self.subTest(value=value),self.assertRaises(ValueError):
                PaperBroker(Config(),None,exit_half_spread_bps=value)

    def test_old_evaluation_cannot_qualify_under_repaired_cost_model(self):
        from dataclasses import asdict
        from samy.service import approval_reasons
        from samy.backtest import EXECUTION_MODEL
        report=dict(kind='strategy_evaluation',strategy='trend',eligible=True,source='binance-public',
                    config=asdict(Config()),test_end=NOW,test=dict(trades=40,net_pnl=1,profit_factor=1.4),stress=dict(net_pnl=.5))
        self.assertTrue(any('execution-cost' in reason for reason in approval_reasons(report,Config(),NOW)))
        report.update(execution_model=EXECUTION_MODEL,historical_spread_bps=HISTORICAL_SPREAD_BPS)
        self.assertEqual(approval_reasons(report,Config(),NOW),[])
