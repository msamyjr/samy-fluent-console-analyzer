from dataclasses import asdict
import io
import json
import time
import unittest
from unittest.mock import patch
from urllib.error import HTTPError,URLError
from samy.config import Config
from samy.data import PublicClient,DataError,HOST
from samy.dataset import synthetic_dataset,validate_dataset
from samy.models import Candle,validate_candles
from samy.indicators import features,correlation


class Response(io.BytesIO):
    def __enter__(self):return self
    def __exit__(self,*args):self.close()


def response(obj):return Response(json.dumps(obj).encode())


class DataTests(unittest.TestCase):
    def test_only_public_get_endpoints(self):
        def opener(req,timeout):
            self.assertEqual(req.get_method(),'GET')
            self.assertTrue(req.full_url.startswith(HOST+'/fapi/v1/time'))
            self.assertFalse(req.has_header('X-mbx-apikey'))
            return response({'serverTime':int(time.time()*1000)})
        c=PublicClient(Config(),opener)
        c.sync()
        for name in ('order','withdraw','listenKey','account','/fapi/v1/order'):
            with self.subTest(name=name),self.assertRaises(DataError):c.get(name)
        with self.assertRaises(DataError):c.get('time',{'signature':'x'})

    def test_dynamic_futures_discovery_excludes_spot_and_inactive(self):
        base=dict(symbol='TESTUSDT',contractType='PERPETUAL',quoteAsset='USDT',marginAsset='USDT',status='TRADING',
          filters=[dict(filterType='PRICE_FILTER',tickSize='0.01'),dict(filterType='LOT_SIZE',stepSize='0.001',minQty='0.001',maxQty='1000'),dict(filterType='MIN_NOTIONAL',notional='5')])
        rows=[base,dict(base,symbol='SPOTUSDT',contractType='SPOT'),dict(base,symbol='DEADUSDT',status='SETTLING'),dict(base,symbol='COINUSD',marginAsset='BTC'),dict(base,symbol='BROKENUSDT',filters=[])]
        c=PublicClient(Config(),lambda *a,**k:response({'symbols':rows}))
        self.assertEqual(list(c.discover()),['TESTUSDT'])

    def test_cache_avoids_repeated_requests(self):
        count=[]
        def opener(*a,**kw):count.append(1);return response({'serverTime':1})
        c=PublicClient(Config(),opener)
        c.get('time',ttl=60);c.get('time',ttl=60)
        self.assertEqual(len(count),1)

    def test_transient_retry_and_permanent_denial(self):
        calls=[]
        def opener(*a,**kw):
            calls.append(1)
            if len(calls)==1:raise HTTPError('url',503,'fixture',{},None)
            return response({'serverTime':1})
        with patch.object(PublicClient,'_sleep'):
            c=PublicClient(Config(),opener)
            self.assertEqual(c.get('time')['serverTime'],1)
        def denied(*a,**kw):raise HTTPError('url',403,'fixture',{},None)
        with self.assertRaises(DataError):PublicClient(Config(),denied).get('time')

    def test_outage_retries_are_bounded(self):
        def outage(*a,**kw):raise URLError('fixture outage')
        with patch.object(PublicClient,'_sleep'),self.assertRaises(DataError):PublicClient(Config(),outage).get('time')

    def test_missing_duplicate_and_invalid_candles(self):
        data=synthetic_dataset(count=150)['symbols']['DEMOAUSDT']['candles']
        candles=[Candle(**x) for x in data]
        validate_candles(candles,60000)
        for bad in (candles[:60]+candles[61:],candles+[candles[-1]],list(reversed(candles))):
            with self.assertRaises(ValueError):validate_candles(bad,60000)
        with self.assertRaises(ValueError):Candle(1,100,99,101,100,1)
        with self.assertRaises(ValueError):Candle(1,100,101,99,float('nan'),1)
        with self.assertRaises(ValueError):Candle(1,100,101,99,100,-1)

    def test_clock_skew_rejected(self):
        c=PublicClient(Config(),lambda *a,**k:response({'serverTime':int(time.time()*1000)-120000}))
        with self.assertRaises(DataError):c.sync()

    def test_indicator_flat_and_spike(self):
        flat=[Candle(i*60000,100,100,100,100,0) for i in range(120)]
        f=features(flat)
        self.assertEqual(f['rsi'],50)
        self.assertEqual(f['volatility'],0)
        spike=flat[:-1]+[Candle(119*60000,100,200,50,200,1000)]
        from samy.indicators import regime
        self.assertEqual(regime(features(spike)),'UNSTABLE')

    def test_correlation_alignment_not_array_position(self):
        a={i:float(i) for i in range(100)}
        b={i:-float(i) for i in range(50,150)}
        self.assertAlmostEqual(correlation(a,b),-1)
        self.assertIsNone(correlation(a,{1000:1}))

    def test_synthetic_data_is_reproducible_and_identified(self):
        a=synthetic_dataset(150)
        self.assertEqual(a,synthetic_dataset(150))
        self.assertNotEqual(a,synthetic_dataset(150,seed=18))
        self.assertEqual(a['source'],'synthetic-demo')
        validate_dataset(a)

    def test_historical_short_final_page_is_accepted(self):
        row=[0,'100','101','99','100','10',59999]
        c=PublicClient(Config(),lambda *a,**kw:response([row]))
        self.assertEqual(len(c.candles('TESTUSDT','1m',limit=1000,start=0,end=60000)),1)
        with self.assertRaises(ValueError):c.candles('TESTUSDT','1m')

    def test_long_retry_after_is_not_ignored(self):
        def limited(*args,**kw):raise HTTPError('url',429,'fixture',{'Retry-After':'120'},None)
        with self.assertRaises(DataError) as caught:PublicClient(Config(),limited).get('time')
        self.assertIn('120',str(caught.exception))

    def test_canceled_client_makes_no_network_request(self):
        def forbidden(*args,**kwargs):raise AssertionError('Network must not run')
        c=PublicClient(Config(),forbidden)
        c.stopped.set()
        with self.assertRaises(DataError):c.get('time')

    def test_invalid_snapshot_funding_is_rejected_before_rendering(self):
        from dataclasses import replace
        from helpers import snapshot
        for changes in (dict(funding=float('nan')),dict(imbalance=2),dict(mark_price=0),dict(oi_change=float('inf'))):
            with self.subTest(changes=changes),self.assertRaises(ValueError):replace(snapshot(),**changes)
