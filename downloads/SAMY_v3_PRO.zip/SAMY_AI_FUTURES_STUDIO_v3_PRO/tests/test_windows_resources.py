"""Resource regressions; Windows backend is mocked when run on Linux."""
from contextlib import closing
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock,patch
from samy.__main__ import ProcessLock
from samy.store import Store


class WindowsResourceTests(unittest.TestCase):
    def test_backup_closes_destination_after_success_and_failure(self):
        with tempfile.TemporaryDirectory() as temp:
            with closing(Store(Path(temp)/'source.sqlite')) as store:
                store.commit({'test':'recoverable'},[])
                for fail in (False,True):
                    with self.subTest(fail=fail):
                        destination=sqlite3.connect(Path(temp)/f'backup-{fail}.sqlite')
                        try:
                            with patch('samy.store.sqlite3.connect',return_value=destination):
                                if fail:
                                    with patch.object(store,'db') as source:
                                        source.backup.side_effect=OSError('simulated backup failure')
                                        with self.assertRaises(OSError):store.backup('unused')
                                else:
                                    store.backup('unused')
                            with self.assertRaises(sqlite3.ProgrammingError):
                                destination.execute('SELECT 1')
                        finally:
                            destination.close()

    def test_lock_initialization_never_reads_protected_bytes(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'server.lock'
            path.write_bytes(b'0')
            with path.open('a+b') as file:
                spy=Mock(wraps=file)
                spy.read.side_effect=PermissionError('Windows byte-range lock denies reads')
                with patch('builtins.open',return_value=spy):
                    lock=ProcessLock(path)
                    try:
                        spy.read.assert_not_called()
                    finally:
                        lock.close()

    def test_initialization_failure_closes_file_and_normalizes_error(self):
        with tempfile.TemporaryDirectory() as temp:
            with (Path(temp)/'server.lock').open('a+b') as file:
                with patch('builtins.open',return_value=file),patch('samy.__main__.os.fstat',side_effect=PermissionError('metadata denied')):
                    with self.assertRaises(RuntimeError) as caught:ProcessLock('unused')
                self.assertTrue(file.closed)
                self.assertIsInstance(caught.exception.__cause__,PermissionError)

    def test_open_failure_is_an_actionable_runtime_error(self):
        with patch('builtins.open',side_effect=PermissionError('access denied')):
            with self.assertRaises(RuntimeError) as caught:ProcessLock('unused')
        self.assertIn('lock file is not writable',str(caught.exception))

    def test_windows_backend_contention_closes_failed_handle(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'server.lock'
            backend=SimpleNamespace(LK_NBLCK=2,locking=Mock(side_effect=[None,PermissionError('locked')]))
            real_open=open
            handles=[]
            def tracked_open(*args,**kwargs):
                file=real_open(*args,**kwargs)
                handles.append(file)
                return file
            with patch('samy.__main__._WINDOWS',True),patch.dict(sys.modules,{'msvcrt':backend}),patch('builtins.open',side_effect=tracked_open):
                holder=ProcessLock(path)
                try:
                    with self.assertRaises(RuntimeError):ProcessLock(path)
                    self.assertFalse(handles[0].closed)
                    self.assertTrue(handles[1].closed)
                    self.assertEqual(backend.locking.call_count,2)
                finally:
                    holder.close()

    def test_native_process_contention_and_release(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'server.lock'
            program='from samy.__main__ import ProcessLock; import sys; lock=ProcessLock(sys.argv[1]); lock.close()'
            command=[sys.executable,'-c',program,str(path)]
            lock=ProcessLock(path)
            try:
                blocked=subprocess.run(command,cwd=Path(__file__).resolve().parents[1],capture_output=True,text=True,timeout=20)
                self.assertNotEqual(blocked.returncode,0)
                self.assertIn('Cannot acquire server lock',blocked.stderr)
            finally:
                lock.close()
            acquired=subprocess.run(command,cwd=Path(__file__).resolve().parents[1],capture_output=True,text=True,timeout=20)
            self.assertEqual(acquired.returncode,0,acquired.stderr)
