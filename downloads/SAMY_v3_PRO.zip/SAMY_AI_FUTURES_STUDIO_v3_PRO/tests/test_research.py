import copy
from dataclasses import asdict,replace
import unittest
from unittest.mock import patch
from samy.config import Config
from samy.dataset import synthetic_dataset,fingerprint
from samy.backtest import run_backtest,evaluate_strategy,metrics
from samy.research import train
from samy.service import approval_reasons
from samy.strategies import STRATEGIES,generate
from samy.models import Candle,Contract,Snapshot
from samy.indicators import features
from helpers import NOW


class ResearchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=synthetic_dataset(850)
        cls.config=Config()

    def test_backtest_reproducible_with_costs_and_ledger_reconciliation(self):
        a=run_backtest(self.data,self.config)
        b=run_backtest(self.data,self.config)
        self.assertEqual(a,b)
        self.assertGreater(a['metrics']['trades'],0)
        self.assertGreater(a['metrics']['fees'],0)
        self.assertAlmostEqual(a['metrics']['net_pnl'],sum(x['net_pnl'] for x in a['trades']))
        self.assertEqual(a['source'],'synthetic-demo')
        self.assertTrue(all(x['qty']>0 for x in a['trades']))
        self.assertTrue(all(x['opened']<x['closed'] for x in a['trades']))
        self.assertAlmostEqual(a['metrics']['net_pnl'],sum(v['net_pnl'] for v in a['by_symbol'].values()))

    def test_future_changes_do_not_change_earlier_backtest_trades(self):
        cutoff=self.data['symbols']['DEMOAUSDT']['candles'][500]['time']
        altered=copy.deepcopy(self.data)
        for item in altered['symbols'].values():
            for c in item['candles'][500:]:
                for k in ('open','high','low','close'):c[k]*=1.2
        a=run_backtest(self.data,self.config,end=cutoff)
        b=run_backtest(altered,self.config,end=cutoff)
        self.assertEqual(a['trades'],b['trades'])
        self.assertEqual(a['metrics'],b['metrics'])

    def test_synthetic_strategy_evidence_cannot_qualify(self):
        report=evaluate_strategy(self.data,self.config,'trend')
        self.assertFalse(report['eligible'])
        self.assertIn('Synthetic fixtures cannot qualify a strategy',report['reasons'])
        self.assertTrue(approval_reasons(report,self.config,NOW))

    def test_real_training_purged_splits_and_inactive_model(self):
        report=train(self.data,self.config)
        self.assertGreater(report['test']['n'],0)
        self.assertLess(report['split']['train_label_end'],report['split']['validation_start'])
        self.assertLess(report['split']['validation_label_end'],report['split']['test_start'])
        for fold in report['walk_forward']:
            self.assertLess(fold['train_end'],fold['validation_start'])
        self.assertFalse(report['active'])
        self.assertTrue(0<=report['test']['brier']<=1)
        self.assertEqual(len(report['parameters']['weights']),6)
        self.assertEqual(sum(x['count'] for x in report['test']['calibration']),report['test']['n'])

    def test_governance_rejects_stale_mismatched_or_failed_evidence(self):
        base=dict(kind='strategy_evaluation',strategy='trend',eligible=True,source='binance-public',
                  execution_model='reference OHLC + executable-side half-spread on entry and exit',historical_spread_bps=2.0,
                  config=asdict(self.config),test_end=NOW,
                  test=dict(trades=40,net_pnl=1,profit_factor=1.4),stress=dict(net_pnl=.5))
        self.assertEqual(approval_reasons(base,self.config,NOW),[])
        for change in [dict(test_end=NOW-31*86400000),dict(source='synthetic-demo'),dict(eligible=False),dict(config={}),dict(test=dict(trades=0)),dict(stress=dict(net_pnl=-1))]:
            with self.subTest(change=change):self.assertTrue(approval_reasons(dict(base,**change),self.config,NOW))

    def test_small_training_and_unknown_strategy_rejected(self):
        with self.assertRaises(ValueError):train(synthetic_dataset(200),self.config)
        with self.assertRaises(ValueError):run_backtest(self.data,self.config,'magic')

    def test_all_strategy_candidates_execute_without_future_inputs(self):
        item=self.data['symbols']['DEMOAUSDT']
        cs=[Candle(**x) for x in item['candles'][:200]]
        price=cs[-1].close
        snap=Snapshot(Contract(**item['contract']),cs[-1].time+60000,price,price*.9999,price*1.0001,
                      100_000_000,0,.0001,1000,{'1m':cs},features(cs)['returns'],source='synthetic-demo')
        self.assertEqual(len(STRATEGIES),10)
        for strategy in STRATEGIES:
            with self.subTest(strategy=strategy):
                signal=generate(snap,strategy)
                if signal:
                    self.assertIn(signal.side,(-1,1))
                    self.assertLessEqual(signal.time,snap.time)

    def test_empty_period_rejected(self):
        with self.assertRaises(ValueError):run_backtest(self.data,self.config,start=NOW+10**12)

    def test_metric_no_trade_is_not_success(self):
        m=metrics([],[[0,75]],75)
        self.assertEqual(m['trades'],0)
        self.assertIsNone(m['win_rate'])
        self.assertIsNone(m['profit_factor'])

    def test_rare_event_accuracy_reports_constant_classifier_and_zero_recall(self):
        from samy.research import scores
        report=scores([.03]*100,[1]+[0]*99)
        self.assertEqual(report['positive_count'],1)
        self.assertEqual(report['positive_rate'],.01)
        self.assertEqual(report['accuracy'],report['always_negative_accuracy'])
        self.assertEqual(report['predicted_positive_count'],0)
        self.assertEqual(report['recall_at_half'],0)
        self.assertIsNone(report['precision_at_half'])
