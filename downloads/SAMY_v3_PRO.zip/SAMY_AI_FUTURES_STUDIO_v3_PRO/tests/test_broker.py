import concurrent.futures
from dataclasses import replace
from pathlib import Path
import tempfile
import unittest
from samy.config import Config
from samy.store import Store
from samy.broker import PaperBroker
from helpers import snapshot,signal,NOW


class BrokerTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.path=Path(self.temp.name)/'paper.sqlite'
        self.store=Store(self.path)
        self.c=Config()
        self.b=PaperBroker(self.c,self.store)

    def tearDown(self):
        self.store.close()
        self.temp.cleanup()

    def open(self,symbol='TESTAUSDT',side=1,now=NOW,phase=1):
        return self.b.open(snapshot(symbol,now,phase),signal(symbol,side,now),now,
                           {'TESTAUSDT':snapshot().returns,'TESTBUSDT':snapshot(phase=2).returns})

    def test_long_fee_accounting(self):
        self.assertTrue(self.open()['approved'])
        self.b.close_observed('TESTAUSDT',102,NOW+1000,'test')
        v=self.b.view();t=v['trades'][0]
        self.assertAlmostEqual(v['cash']-75,t['net_pnl'])
        self.assertAlmostEqual(v['fees'],t['entry_fee']+t['exit_fee'])
        self.assertGreater(t['net_pnl'],0)

    def test_short_pnl(self):
        self.open(side=-1)
        self.b.close_observed('TESTAUSDT',98,NOW+1000,'test')
        self.assertGreater(self.b.view()['trades'][0]['net_pnl'],0)

    def test_two_positions_and_third_rejected(self):
        self.assertTrue(self.open()['approved'])
        self.assertTrue(self.open('TESTBUSDT',side=-1,phase=2)['approved'])
        result=self.open('TESTCUSDT',phase=3)
        self.assertFalse(result['approved'])
        self.assertIn('maximum simultaneous',result['reason'])
        self.assertEqual(len(self.b.state['positions']),2)
        self.assertLessEqual(self.b.view()['planned_risk'],.75)

    def test_correlation_rejected(self):
        self.open()
        r=self.open('TESTBUSDT',phase=1)
        self.assertFalse(r['approved']);self.assertIn('correlated',r['reason'])

    def test_missing_correlation_rejected(self):
        self.open()
        r=self.b.open(snapshot('TESTBUSDT'),signal('TESTBUSDT'),NOW,{})
        self.assertIn('correlation history',r['reason'])

    def test_duplicate_signal_survives_close_and_restart(self):
        self.open()
        self.b.close_observed('TESTAUSDT',101,NOW+1000,'test')
        restored=PaperBroker(self.c,self.store)
        decision=restored.open(snapshot(now=NOW+2000),signal(),NOW+2000,{})
        self.assertFalse(decision['approved']);self.assertIn('duplicate',decision['reason'])

    def test_restart_preserves_position_and_emergency_stop(self):
        self.open();self.b.kill(NOW+1)
        restored=PaperBroker(self.c,self.store)
        self.assertEqual(restored.state,self.b.state)
        self.assertTrue(restored.state['killed'])

    def test_funding_long_and_duplicate(self):
        self.open()
        qty=self.b.state['positions']['TESTAUSDT']['qty']
        self.b.funding('TESTAUSDT',.0001,100,NOW+1000,NOW+1000)
        cash=self.b.state['cash']
        self.b.funding('TESTAUSDT',.0001,100,NOW+1000,NOW+1000)
        self.assertEqual(self.b.state['cash'],cash)
        self.assertAlmostEqual(self.b.state['funding'],qty*100*.0001)
        self.b.close_observed('TESTAUSDT',100,NOW+2000,'test')
        self.assertAlmostEqual(self.b.view()['realized'],self.b.state['cash']-75)

    def test_short_receives_positive_funding(self):
        self.open(side=-1)
        before=self.b.state['cash']
        self.b.funding('TESTAUSDT',.0001,100,NOW+1000,NOW+1000)
        self.assertGreater(self.b.state['cash'],before)

    def test_stop_first_if_both_touched(self):
        self.open()
        self.b.mark('TESTAUSDT',100,NOW+60000,high=104,low=98)
        t=self.b.state['trades'][0]
        self.assertIn('stop-loss',t['reason']);self.assertLess(t['net_pnl'],0)

    def test_take_profit(self):
        self.open()
        self.b.mark('TESTAUSDT',102,NOW+60000,high=103,low=100)
        self.assertIn('take-profit',self.b.state['trades'][0]['reason'])

    def test_gap_stop_exceeds_planned_budget(self):
        self.open()
        risk=self.b.state['positions']['TESTAUSDT']['risk']
        self.b.mark('TESTAUSDT',90,NOW+60000)
        self.assertLess(self.b.state['trades'][0]['net_pnl'],-risk)

    def test_liquidation_and_insurance_accounting(self):
        self.open()
        self.b.mark('TESTAUSDT',1,NOW+60000)
        self.assertEqual(len(self.b.state['positions']),0)
        self.assertIn('liquidation',self.b.state['trades'][0]['reason'])
        self.assertGreaterEqual(self.b.state['cash'],0)
        self.assertGreater(self.b.state['insurance_deficit'],0)

    def test_duplicate_and_out_of_order_quotes(self):
        self.open();self.b.mark('TESTAUSDT',100.1,NOW+1000)
        original=self.b.view()
        self.b.mark('TESTAUSDT',100.1,NOW+1000)
        self.assertEqual(self.b.view(),original)
        with self.assertRaises(ValueError):self.b.mark('TESTAUSDT',100,NOW-1)

    def test_invalid_price_rejected(self):
        self.open()
        for price in (0,-1,float('nan'),float('inf')):
            with self.subTest(price=price),self.assertRaises(ValueError):self.b.mark('TESTAUSDT',price,NOW+1000)

    def test_loss_cooldown(self):
        for i in range(3):
            now=NOW+i*10000
            self.open(now=now)
            self.b.close_observed('TESTAUSDT',99.5,now+1000,'test')
        self.assertEqual(self.b.state['loss_streak'],3)
        r=self.open(now=NOW+40000)
        self.assertIn('cooldown',r['reason'])

    def test_atomic_race_no_duplicate_positions(self):
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            results=list(pool.map(lambda _:self.open(),range(20)))
        self.assertEqual(sum(x['approved'] for x in results),1)
        self.assertEqual(len(self.b.state['positions']),1)
        self.assertEqual(self.store.load(),self.b.state)

    def test_sqlite_backup_recovery(self):
        self.open()
        backup=Path(self.temp.name)/'backup.sqlite'
        self.store.backup(backup)
        restored=Store(backup)
        try:self.assertEqual(restored.load(),self.b.state)
        finally:restored.close()

    def test_database_commit_failure_rolls_back_memory(self):
        original=self.b.view()
        saved=self.store.commit
        def fail(*args):raise OSError('disk failure fixture')
        self.store.commit=fail
        try:
            with self.assertRaises(OSError):self.open()
            self.assertEqual(self.b.view(),original)
        finally:self.store.commit=saved

    def test_time_exit(self):
        self.open()
        self.b.mark('TESTAUSDT',100,NOW+self.c.max_hold_seconds*1000)
        self.assertEqual(self.b.state['trades'][0]['reason'],'maximum holding time')

    def test_emergency_closes_on_next_observed_quote(self):
        self.open()
        self.b.kill(NOW+1)
        self.b.mark('TESTAUSDT',100,NOW+1000)
        self.assertFalse(self.b.state['positions'])
        self.assertEqual(self.b.state['trades'][0]['reason'],'emergency stop')

    def test_extreme_funding_cannot_create_negative_cash_or_erase_costs(self):
        self.open()
        self.b.funding('TESTAUSDT',.99,10000,NOW+1000,NOW+1000)
        self.assertGreaterEqual(self.b.state['cash'],0)
        self.assertFalse(self.b.state['positions'])
        self.assertGreater(self.b.state['insurance_deficit'],0)
        self.assertAlmostEqual(self.b.view()['realized'],self.b.state['cash']-75)

    def test_margin_exhaustion_rejects_without_rounding_up(self):
        from samy.risk import RiskEngine
        from samy.broker import initial_state
        c=replace(self.c,max_margin_fraction=.01)
        result=RiskEngine(c).evaluate(initial_state(c),snapshot(),signal(),NOW,{})
        self.assertFalse(result.approved)
        self.assertIn('minimum',result.reason)

    def test_short_stop_and_target_directions(self):
        self.open(side=-1)
        self.b.mark('TESTAUSDT',102,NOW+1000)
        self.assertLess(self.b.state['trades'][0]['net_pnl'],0)
        self.assertIn('stop-loss',self.b.state['trades'][0]['reason'])

    def test_restart_with_changed_initial_capital_rejected(self):
        self.open()
        with self.assertRaises(ValueError):PaperBroker(replace(self.c,initial_balance=100),self.store)

    def test_risk_configuration_change_with_open_positions_rejected(self):
        self.open()
        with self.assertRaises(ValueError):PaperBroker(replace(self.c,trade_risk=.004),self.store)
