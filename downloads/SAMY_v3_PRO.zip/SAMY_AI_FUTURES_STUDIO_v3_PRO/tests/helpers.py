import math
from samy.models import Contract,Snapshot,Signal

NOW=1735689600000


def snapshot(symbol='TESTAUSDT',now=NOW,phase=1,price=100):
    returns={NOW-i*60000:math.sin(i*phase)*0.001 for i in range(100)}
    return Snapshot(Contract(symbol,0.01,0.001,0.001,5),now,price,price-.01,price+.01,
                    100_000_000,0,0.0001,1000,{},returns,mark_price=price)


def signal(symbol='TESTAUSDT',side=1,now=NOW,strategy='trend',price=100):
    return Signal(symbol,side,strategy,price-side,price+2*side,50,'Test fixture','BULL TREND',0.001,now)
