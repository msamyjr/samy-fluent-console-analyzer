import copy
from dataclasses import replace
import math
import random
import unittest
from samy.config import Config
from samy.models import Contract,Signal,quantize
from samy.risk import RiskEngine,equity
from samy.broker import initial_state
from helpers import snapshot,signal,NOW


class RiskTests(unittest.TestCase):
    def setUp(self):
        self.c=Config()
        self.risk=RiskEngine(self.c)
        self.state=initial_state(self.c)

    def check_reject(self,snap=None,sig=None,reason=None,state=None):
        r=self.risk.evaluate(state or self.state,snap or snapshot(),sig or signal(),NOW,{})
        self.assertFalse(r.approved,r)
        if reason:self.assertIn(reason,r.reason)
        return r

    def test_default_budgets(self):
        r=self.risk.evaluate(self.state,snapshot(),signal(),NOW,{})
        self.assertTrue(r.approved)
        self.assertLessEqual(r.risk,0.375)
        self.assertLessEqual(r.margin,37.5)
        self.assertGreater(r.qty,0)

    def test_short_sizing(self):
        r=self.risk.evaluate(self.state,snapshot(),signal(side=-1),NOW,{})
        self.assertTrue(r.approved)
        self.assertGreater(r.stop,r.entry)
        self.assertLess(r.target,r.entry)

    def test_stale_and_future_data(self):
        for dt in (-21000,2000):
            with self.subTest(dt=dt):self.check_reject(snapshot(now=NOW+dt),reason='market data')

    def test_stale_signal(self):
        self.check_reject(sig=signal(now=NOW-91000),reason='stale signal')

    def test_invalid_market_values(self):
        for name,value in [('price',float('nan')),('bid',0),('ask',float('inf')),('funding',float('nan')),('open_interest',-1)]:
            snap=snapshot();setattr(snap,name,value)
            with self.subTest(name=name):self.check_reject(snap,reason='invalid market')

    def test_wrong_bid_ask(self):
        snap=snapshot();snap.bid=101;snap.ask=99
        self.check_reject(snap,reason='bid/ask')

    def test_spread(self):
        snap=snapshot();snap.ask=101
        self.check_reject(snap,reason='spread')

    def test_liquidity(self):
        snap=snapshot();snap.quote_volume=1
        self.check_reject(snap,reason='liquidity')

    def test_minimum_notional_rejected_without_leverage_escalation(self):
        snap=snapshot();snap.contract=Contract('TESTAUSDT',.01,.001,.001,1000)
        self.check_reject(snap,reason='minimum')
        self.assertEqual(self.c.leverage,2)

    def test_wrong_stops(self):
        self.check_reject(sig=replace(signal(),stop=101),reason='wrong side')
        self.check_reject(sig=replace(signal(),target=99),reason='wrong side')

    def test_near_liquidation(self):
        self.check_reject(sig=replace(signal(),stop=60),reason='liquidation')

    def test_emergency_stop(self):
        self.state['killed']=True
        self.check_reject(reason='emergency')

    def test_daily_weekly_and_drawdown(self):
        for cash,day,week,high,reason in [(73,75,75,75,'daily'),(71,71,75,75,'weekly'),(68,68,68,75,'drawdown')]:
            state=copy.deepcopy(self.state)
            state.update(cash=cash,day_equity=day,week_equity=week,high_water=high)
            self.check_reject(state=state,reason=reason)

    def test_cooldown(self):
        self.state['cooldown_until']=NOW+1000
        self.check_reject(reason='cooldown')

    def test_configuration_rejects_unsafe_values(self):
        for values in [dict(trade_risk=.01),dict(total_risk=.02),dict(max_positions=3),dict(leverage=4),dict(fee_rate=float('nan')),dict(concurrency=10),dict(max_positions=1.5),dict(min_history=10),dict(timeframes=['1h']),dict(max_correlation=2)]:
            with self.subTest(values=values),self.assertRaises(ValueError):Config(**values)

    def test_quantity_rounding(self):
        self.assertEqual(quantize(.123456,.001),.123)
        self.assertEqual(quantize(1.234,.05,up=True),1.25)
        self.assertEqual(quantize(1.25,.05),1.25)

    def test_randomized_sizing_invariants(self):
        rng=random.Random(44)
        for _ in range(300):
            price=10**rng.uniform(-1,4)
            snap=snapshot(price=price)
            snap.bid=price*(1-.0001);snap.ask=price*(1+.0001)
            snap.contract=Contract('TESTAUSDT',price/100000,10**rng.randint(-5,-1),.00001,5)
            distance=price*rng.uniform(.003,.05)
            side=rng.choice((-1,1))
            sig=Signal('TESTAUSDT',side,'trend',price-side*distance,price+2*side*distance,50,'fixture','SIDEWAYS',rng.uniform(.0001,.02),NOW)
            r=self.risk.evaluate(self.state,snap,sig,NOW,{})
            if r.approved:
                self.assertLessEqual(r.risk,75*.005+1e-10)
                self.assertLessEqual(r.margin,37.5+1e-10)
                self.assertGreaterEqual(r.qty*r.entry,5)
                self.assertAlmostEqual(r.qty/snap.contract.step,round(r.qty/snap.contract.step),places=6)

    def test_target_cannot_be_smaller_than_cost_reserve(self):
        self.check_reject(sig=replace(signal(),target=100.1),reason='costs')
