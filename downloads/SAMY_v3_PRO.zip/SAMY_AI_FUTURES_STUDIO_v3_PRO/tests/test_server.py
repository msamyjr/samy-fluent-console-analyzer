import asyncio
import json
from pathlib import Path
import re
import tempfile
import threading
import time
import unittest
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from unittest.mock import patch
from samy.config import Config
from samy.store import Store
from samy.broker import PaperBroker
from samy.service import Service
from samy.server import make_server
from samy.__main__ import ProcessLock


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.store=Store(Path(self.tmp.name)/'paper.sqlite')
        self.b=PaperBroker(Config(),self.store)
        self.service=Service(Config(),self.store,self.b,demo=True)
        asyncio.run(self.service.cycle())
        self.server=make_server(self.service,0)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()
        self.url=f'http://127.0.0.1:{self.server.server_port}'

    def tearDown(self):
        self.server.shutdown();self.server.server_close();self.thread.join()
        self.store.close();self.tmp.cleanup()

    def test_dashboard_and_real_state(self):
        with urlopen(self.url) as r:
            self.assertEqual(r.status,200)
            self.assertIn('PAPER ONLY',r.read().decode())
        with urlopen(self.url+'/api/state') as r:
            state=json.load(r)
        self.assertEqual(state['account']['equity'],75)
        self.assertEqual(state['health']['source'],'SYNTHETIC DEMO')
        self.assertEqual(len(state['markets']),3)
        self.assertEqual(state['account']['positions'],{})

    def test_assets_and_export(self):
        for route in ('/style.css','/app.js','/api/export'):
            with self.subTest(route=route),urlopen(self.url+route) as r:self.assertEqual(r.status,200)

    def test_emergency_stop_requires_session_token(self):
        req=Request(self.url+'/api/kill',data=b'{}',headers={'Content-Type':'application/json'},method='POST')
        with self.assertRaises(HTTPError) as caught:urlopen(req)
        self.assertEqual(caught.exception.code,403)
        self.assertFalse(self.b.state['killed'])
        with urlopen(self.url) as r:html=r.read().decode()
        token=re.search('name="samy-token" content="([^"]+)"',html).group(1)
        req.add_header('X-Samy-Token',token)
        with urlopen(req) as r:self.assertEqual(r.status,200)
        self.assertTrue(self.b.state['killed'])

    def test_dns_rebinding_host_rejected(self):
        req=Request(self.url+'/api/state',headers={'Host':'evil.example'})
        with self.assertRaises(HTTPError) as caught:urlopen(req)
        self.assertEqual(caught.exception.code,403)

    def test_no_live_order_or_file_traversal_route(self):
        for route in ('/api/order','/api/live','/../config/paper.json'):
            with self.subTest(route=route),self.assertRaises(HTTPError) as caught:urlopen(self.url+route)
            self.assertEqual(caught.exception.code,404)

    def test_process_lock(self):
        lock=ProcessLock(Path(self.tmp.name)/'server.lock')
        try:
            with self.assertRaises(RuntimeError):ProcessLock(Path(self.tmp.name)/'server.lock')
        finally:lock.close()
        again=ProcessLock(Path(self.tmp.name)/'server.lock');again.close()

    def test_network_failure_does_not_create_orders(self):
        self.service.demo=False
        def fail():raise RuntimeError('fixture outage')
        with patch.object(self.service.client,'sync',side_effect=fail):
            with self.assertRaises(RuntimeError):asyncio.run(self.service.cycle())
        self.assertFalse(self.b.state['positions'])

    def test_ranked_autonomous_cycle_opens_two_mock_markets_then_rejects_third(self):
        from dataclasses import asdict
        from unittest.mock import AsyncMock
        from samy.dataset import synthetic_dataset
        from samy.models import Candle,Contract,Snapshot,Signal
        from samy.indicators import features
        from helpers import snapshot as fixture_snapshot
        now=int(time.time()*1000)
        fixtures=synthetic_dataset(150,start=now//60000*60000-150*60000)
        snapshots={}
        for i,(symbol,item) in enumerate(fixtures['symbols'].items()):
            cs=[Candle(**x) for x in item['candles']]
            snapshots[symbol]=Snapshot(Contract(**item['contract']),now,100,99.99,100.01,100_000_000,0,.0001,1000,
                                      {'1m':cs},fixture_snapshot(phase=i+1).returns)
        self.service.demo=False
        self.service.client.synced_at=time.monotonic()
        self.service.client.discover=lambda:{s:x.contract for s,x in snapshots.items()}
        self.service.client.request=AsyncMock(return_value=[dict(symbol=s,quoteVolume=100_000_000) for s in snapshots])
        self.service.client.snapshot=AsyncMock(side_effect=lambda contract,ticker:snapshots[contract.symbol])
        report=dict(kind='strategy_evaluation',strategy='trend',eligible=True,source='binance-public',
                    config=asdict(Config()),test_end=now,test=dict(trades=40,net_pnl=1,profit_factor=1.4),stress=dict(net_pnl=.5))
        self.store.artifact('mock-evidence','approved_strategy',report)
        def candidate(snap,strategy):
            return Signal(snap.contract.symbol,1,'trend',99,102,50,'Mock strategy for integration test','BULL TREND',.001,now) if strategy=='trend' else None
        with patch('samy.service.generate',side_effect=candidate):
            asyncio.run(self.service.cycle())
        self.assertEqual(len(self.b.state['positions']),2)
        self.assertLessEqual(self.b.view()['planned_risk'],.75)
        self.assertTrue(any(r['signal']=='REJECTED BY RISK ENGINE' for r in self.service.rows.values()))
