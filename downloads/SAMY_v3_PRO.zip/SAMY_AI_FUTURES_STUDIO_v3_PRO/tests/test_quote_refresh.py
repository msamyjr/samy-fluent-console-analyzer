"""Separate transport/freshness of display quotes and strategy snapshots."""
import asyncio
from contextlib import closing
import io
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch,Mock
from samy.broker import PaperBroker
from samy.config import Config
from samy.data import PublicClient,DataError
from samy.service import Service
from samy.store import Store


class QuoteTransportTests(unittest.TestCase):
    def test_public_quote_request_filters_symbols_and_rejects_bad_data(self):
        now=int(time.time()*1000)
        rows=[dict(symbol='GOODUSDT',bidPrice='99',askPrice='101',time=now),
              dict(symbol='BADUSDT',bidPrice='NaN',askPrice='101',time=now),
              dict(symbol='FUTUREUSDT',bidPrice='99',askPrice='101',time=now+5000),
              dict(symbol='SPOTONLYUSDT',bidPrice='99',askPrice='101',time=now)]
        def opener(request,timeout):
            self.assertEqual(request.get_method(),'GET')
            self.assertTrue(request.full_url.endswith('/fapi/v1/ticker/bookTicker'))
            self.assertFalse(request.has_header('X-mbx-apikey'))
            return io.BytesIO(json.dumps(rows).encode())
        client=PublicClient(Config(),opener)
        quotes,errors=client.best_quotes({'GOODUSDT','BADUSDT','FUTUREUSDT','MISSINGUSDT'})
        self.assertEqual(set(quotes),{'GOODUSDT'})
        self.assertEqual(quotes['GOODUSDT']['price'],100)
        self.assertEqual(quotes['GOODUSDT']['quote_time'],now)
        self.assertEqual(set(errors),{'BADUSDT','FUTUREUSDT','MISSINGUSDT'})

    def test_old_event_time_is_retained_not_replaced_with_request_time(self):
        old=int(time.time()*1000)-600000
        client=PublicClient(Config(),lambda *a,**kw:io.BytesIO(json.dumps([dict(symbol='OLDUSDT',bidPrice=99,askPrice=101,time=old)]).encode()))
        quotes,errors=client.best_quotes({'OLDUSDT'})
        self.assertEqual(quotes['OLDUSDT']['quote_time'],old)
        self.assertFalse(errors)

    def test_malformed_top_level_response_fails_closed(self):
        client=PublicClient(Config(),lambda *a,**kw:io.BytesIO(b'{}'))
        with self.assertRaises(DataError):client.best_quotes({'TESTUSDT'})

    def test_duplicate_response_rows_keep_newest_event(self):
        now=int(time.time()*1000)
        rows=[dict(symbol='TESTUSDT',bidPrice=109,askPrice=111,time=now),
              dict(symbol='TESTUSDT',bidPrice=89,askPrice=91,time=now-5000)]
        client=PublicClient(Config(),lambda *args,**kw:io.BytesIO(json.dumps(rows).encode()))
        quotes,errors=client.best_quotes({'TESTUSDT'})
        self.assertEqual(quotes['TESTUSDT']['price'],110)
        self.assertEqual(quotes['TESTUSDT']['quote_time'],now)

    def test_invalid_snapshot_quote_timestamp_rejected(self):
        from dataclasses import replace
        from helpers import snapshot
        for value in (0,-1,float('nan'),float('inf'),'invalid'):
            with self.subTest(value=value),self.assertRaises(ValueError):replace(snapshot(),quote_time=value)


class QuoteServiceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.store=Store(Path(self.temp.name)/'paper.sqlite')
        self.broker=PaperBroker(Config(),self.store)
        self.service=Service(Config(),self.store,self.broker)
        self.now=int(time.time()*1000)
        self.service.known_symbols={'TESTUSDT'}

    def tearDown(self):
        self.store.close();self.temp.cleanup()

    def quote(self,t=None,price=100):
        return dict(price=price,bid=price-.01,ask=price+.01,spread_bps=2,quote_time=t or self.now)

    def test_price_refresh_does_not_renew_expired_analysis_or_open_positions(self):
        self.service.rows['TESTUSDT']=dict(symbol='TESTUSDT',price=90,quote_time=self.now-300000,
            time=self.now-300000,analysis_time=self.now-300000,funding=None,signal='LONG CANDIDATE',score=90,reason='old candidate')
        self.service.client.best_quotes=Mock(return_value=({'TESTUSDT':self.quote()},{}))
        with patch.object(self.broker,'open',side_effect=AssertionError('quotes cannot open positions')),patch.object(self.broker,'mark',side_effect=AssertionError('display quotes cannot mark positions')):
            asyncio.run(self.service.quote_cycle())
        result=self.service.view()
        row=result['markets'][0]
        self.assertFalse(row['quote_stale'])
        self.assertTrue(row['analysis_stale'])
        self.assertEqual(row['signal'],'WAIT')
        self.assertEqual(row['score'],0)
        self.assertEqual(row['price'],100)
        self.assertEqual(result['health']['fresh_quotes'],1)
        self.assertEqual(result['health']['fresh_analyses'],0)
        self.assertFalse(result['account']['positions'])
        self.assertEqual(self.service.rows['TESTUSDT']['analysis_time'],self.now-300000)

    def test_unknown_analysis_is_pending_not_invented(self):
        self.service.client.best_quotes=Mock(return_value=({'TESTUSDT':self.quote()},{}))
        asyncio.run(self.service.quote_cycle())
        row=self.service.view()['markets'][0]
        self.assertTrue(row['analysis_stale'])
        self.assertIsNone(row['analysis_age_seconds'])
        self.assertIsNone(row['funding'])
        self.assertIn('pending',row['reason'])
        self.assertEqual(row['signal'],'WAIT')

    def test_stale_event_is_not_fresh_despite_recent_refresh_heartbeat(self):
        self.service.client.best_quotes=Mock(return_value=({'TESTUSDT':self.quote(t=self.now-600000)},{}))
        asyncio.run(self.service.quote_cycle())
        view=self.service.view()
        self.assertTrue(view['markets'][0]['quote_stale'])
        self.assertFalse(view['health']['data_fresh'])
        self.assertEqual(view['health']['fresh_quotes'],0)

    def test_out_of_order_quotes_cannot_overwrite_newer_price(self):
        self.service.rows['TESTUSDT']=dict(symbol='TESTUSDT',**self.quote(price=110),time=0,analysis_time=0)
        self.service.client.best_quotes=Mock(return_value=({'TESTUSDT':self.quote(t=self.now-5000,price=90)},{}))
        asyncio.run(self.service.quote_cycle())
        self.assertEqual(self.service.rows['TESTUSDT']['price'],110)
        self.assertEqual(self.service.rows['TESTUSDT']['quote_time'],self.now)

    def test_analysis_error_is_visible_with_a_current_price(self):
        self.service.rows['TESTUSDT']=dict(symbol='TESTUSDT',price=None,quote_time=0,time=0,analysis_time=0,
            signal='WAIT',score=0,reason='Analysis rejected: stale open interest',analysis_error=True)
        self.service.client.best_quotes=Mock(return_value=({'TESTUSDT':self.quote()},{}))
        asyncio.run(self.service.quote_cycle())
        row=self.service.view()['markets'][0]
        self.assertEqual(row['price'],100)
        self.assertFalse(row['quote_stale'])
        self.assertIn('open interest',row['reason'])
        self.assertTrue(row['analysis_error'])

    def test_missing_quote_is_unavailable_not_zero(self):
        self.service.client.best_quotes=Mock(return_value=({}, {'TESTUSDT':'missing timestamp'}))
        asyncio.run(self.service.quote_cycle())
        row=self.service.view()['markets'][0]
        self.assertIsNone(row['price'])
        self.assertIsNone(row['funding'])
        self.assertTrue(row['quote_stale'])

    def test_heartbeat_does_not_override_stale_price(self):
        self.service.rows['TESTUSDT']=dict(symbol='TESTUSDT',price=100,quote_time=self.now-600000,time=self.now,
            analysis_time=self.now,signal='LONG CANDIDATE',score=90)
        self.service._update(last_scan=self.now,quote_status='CONNECTED')
        result=self.service.view()
        self.assertFalse(result['health']['data_fresh'])
        self.assertEqual(result['markets'][0]['signal'],'WAIT')

    def test_quote_lane_is_not_blocked_by_analysis_semaphore(self):
        self.service.client.best_quotes=Mock(return_value=({'TESTUSDT':self.quote()},{}))
        async def run():
            for _ in range(self.service.c.concurrency):await self.service.client.sem.acquire()
            try:await asyncio.wait_for(self.service.quote_cycle(),timeout=2)
            finally:
                for _ in range(self.service.c.concurrency):self.service.client.sem.release()
        asyncio.run(run())
        self.assertEqual(self.service.rows['TESTUSDT']['price'],100)

    def test_refresh_continues_while_analysis_is_awaiting_io(self):
        entered=None
        self.service.client.best_quotes=Mock(return_value=({'TESTUSDT':self.quote()},{}))
        async def run():
            entered=asyncio.Event();release=asyncio.Event()
            async def slow_cycle():
                entered.set();await release.wait()
            original=self.service.quote_cycle
            async def quotes():
                await entered.wait();await original();self.service.stop.set();release.set()
            with patch.object(self.service,'cycle',side_effect=slow_cycle),patch.object(self.service,'quote_cycle',side_effect=quotes):
                await asyncio.wait_for(self.service.run(),timeout=3)
        asyncio.run(run())
        self.assertEqual(self.service.rows['TESTUSDT']['price'],100)
        self.assertFalse(self.broker.state['positions'])

    def test_failed_analysis_preserves_good_quote_and_removes_candidate(self):
        self.service.rows['TESTUSDT']=dict(symbol='TESTUSDT',**self.quote(),analysis_time=self.now,signal='LONG CANDIDATE',score=80)
        self.service._analysis_failed('TESTUSDT','stale funding data')
        row=self.service.view()['markets'][0]
        self.assertEqual(row['price'],100)
        self.assertFalse(row['quote_stale'])
        self.assertEqual(row['signal'],'WAIT')
        self.assertTrue(row['analysis_stale'])
        self.assertIn('stale funding',row['reason'])

class QuoteThrottleTests(unittest.TestCase):
    def test_long_retry_after_is_shared_with_later_quote_requests(self):
        from urllib.error import HTTPError
        def limited(*args,**kwargs):raise HTTPError('url',429,'rate limited',{'Retry-After':'120'},None)
        client=PublicClient(Config(),limited)
        before=time.monotonic()
        with self.assertRaises(DataError):client.get('book_ticker')
        self.assertGreaterEqual(client.retry_not_before,before+119)
        waits=[]
        def wait(seconds):
            waits.append(seconds)
            client.retry_not_before=0
        with patch.object(client,'_sleep',side_effect=wait):client._reserve(10)
        self.assertEqual(len(waits),1)
        self.assertGreater(waits[0],119)

    def test_shutdown_interrupts_rate_limit_wait_without_a_request(self):
        client=PublicClient(Config(),lambda *args,**kwargs:(_ for _ in ()).throw(AssertionError('no network')))
        client.retry_not_before=time.monotonic()+120
        client.stopped.set()
        with self.assertRaises(DataError):client.get('book_ticker')
