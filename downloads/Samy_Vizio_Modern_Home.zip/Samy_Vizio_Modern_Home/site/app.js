/* ES5 syntax and XHR for older TV engines. No libraries, tracking, or TV tokens. */
(function () {
  'use strict';
  var control = document.body.getAttribute('data-mode') === 'control';
  var apps = [], favorites = [], filter = 'all', csrf = '', offline = true, busy = false;
  var notice = document.getElementById('notice'), search = document.getElementById('search');
  var storageKey = 'samy-home-favorites-v1', storageAvailable = true;
  function tell(text, error) { notice.textContent = text; notice.className = 'notice' + (error ? ' error' : ''); }
  function loadFavorites() {
    try { var value = JSON.parse(localStorage.getItem(storageKey) || '[]'); if (Object.prototype.toString.call(value) === '[object Array]') favorites = value.filter(function (v) { return typeof v === 'string'; }); }
    catch (e) { storageAvailable = false; }
  }
  function isFavorite(id) { return favorites.indexOf(id) !== -1; }
  function saveFavorite(id) {
    var i = favorites.indexOf(id);
    if (i === -1) favorites.push(id); else favorites.splice(i, 1);
    try { localStorage.setItem(storageKey, JSON.stringify(favorites)); } catch (e) { storageAvailable = false; }
    tell((i === -1 ? 'أُضيف إلى المفضّلة.' : 'أُزيل من المفضّلة.') + (storageAvailable ? ' تُحفظ محليًا في هذا المتصفح.' : ' التخزين غير متاح؛ الحفظ لهذه الجلسة فقط.'));
  }
  function request(path, body, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open(body === null ? 'GET' : 'POST', path, true);
    xhr.timeout = 30000;
    if (body !== null) { xhr.setRequestHeader('Content-Type', 'application/json'); xhr.setRequestHeader('X-Samy-CSRF', csrf); }
    xhr.onload = function () {
      var data;
      try { data = JSON.parse(xhr.responseText); } catch (e) { callback('استجابة غير صالحة من الخادم.'); return; }
      if (xhr.status < 200 || xhr.status >= 300 || data.ok === false) { callback('تعذرت العملية. تحقق من اتصال التلفاز والإعداد المحلي؛ تفاصيل التشخيص في Terminal.'); return; }
      callback(null, data);
    };
    xhr.onerror = function () { callback('تعذر الاتصال بالخادم المحلي.'); };
    xhr.ontimeout = function () { callback('انتهت مهلة الطلب. تحقق من الاتصال.'); };
    xhr.send(body === null ? null : JSON.stringify(body));
  }
  function output(data) { var out = document.getElementById('result'); if (out) out.textContent = JSON.stringify(data, null, 2); }
  function command(path, body) {
    if (!control) { tell('لتشغيل أمر أصلي، استخدم لوحة Mac المحلية. صفحة التلفاز ثابتة للعرض فقط.'); return; }
    if (offline) { tell('معاينة دون تلفاز. نفّذ setup على Mac ثم أعد تشغيل الخادم.', true); return; }
    if (busy) { tell('انتظر اكتمال الأمر السابق.'); return; }
    busy = true; document.body.classList.add('busy'); tell('جارٍ إرسال الأمر…');
    request(path, body, function (error, data) {
      busy = false; document.body.classList.remove('busy');
      if (error) { tell(error, true); return; }
      output(data); tell('قَبِل API الأمر فقط. تحقق من النتيجة على شاشة التلفاز؛ للتطبيقات اقرأ «التطبيق الحالي» أيضًا.');
    });
  }
  function read(path, callback) {
    if (offline) { tell('لا يوجد تلفاز متصل في المعاينة المحلية.', true); return; }
    tell('جارٍ قراءة بيانات التلفاز…');
    request(path, null, function (error, data) {
      if (error) { tell(error, true); return; }
      output(data); tell('اكتملت قراءة API. لا يعني ذلك اختبار العرض أو تشغيل الفيديو.');
      if (callback) callback(data.data);
    });
  }
  function element(tag, className, text) {
    var e = document.createElement(tag); if (className) e.className = className; if (text !== undefined) e.textContent = text; return e;
  }
  function launch(app) {
    if (app.type === 'native') { command('/api/app', {app: app.id}); return; }
    if (!/^https:\/\//.test(app.url)) { tell('رابط غير مسموح.', true); return; }
    window.location.href = app.url;
  }
  function render(focusId) {
    var host = document.getElementById('apps'), query = search.value.toLowerCase().replace(/^\s+|\s+$/g, '');
    host.textContent = ''; var shown = 0;
    apps.forEach(function (app) {
      if (query && (app.name + ' ' + app.description).toLowerCase().indexOf(query) === -1) return;
      if (filter === 'favorites' && !isFavorite(app.id)) return;
      if ((filter === 'native' || filter === 'web') && app.type !== filter) return;
      shown++;
      var card = element('article', 'app-card app-' + app.id);
      card.setAttribute('data-app-id', app.id);
      var button = element('button', 'app-launch'); button.type = 'button'; button.setAttribute('aria-label', app.name + ' — ' + app.description);
      var art = element('span', 'app-art', app.symbol), info = element('span', 'app-info');
      art.setAttribute('aria-hidden', 'true');
      info.appendChild(element('strong', 'app-title', app.name)); info.appendChild(element('span', 'app-caption', app.description));
      button.appendChild(art); button.appendChild(info); button.addEventListener('click', function () { launch(app); });
      var favorite = element('button', 'favorite' + (isFavorite(app.id) ? ' saved' : ''), isFavorite(app.id) ? '★' : '☆');
      favorite.type = 'button'; favorite.setAttribute('aria-label', 'مفضّلة ' + app.name); favorite.setAttribute('aria-pressed', isFavorite(app.id) ? 'true' : 'false');
      favorite.addEventListener('click', function () { saveFavorite(app.id); render(app.id); });
      card.appendChild(button); card.appendChild(favorite); host.appendChild(card);
    });
    document.getElementById('count').textContent = shown + ' تطبيق / موقع';
    document.getElementById('empty').hidden = shown !== 0;
    if (focusId) {
      var cards = host.querySelectorAll('.app-card'), found = false;
      for (var i = 0; i < cards.length; i++) if (cards[i].getAttribute('data-app-id') === focusId) { cards[i].querySelector('.favorite').focus(); found = true; break; }
      if (!found) document.querySelector('[data-filter="' + filter + '"]').focus();
    }
  }
  function setFilter(value) {
    filter = value;
    var buttons = document.querySelectorAll('[data-filter]');
    for (var i = 0; i < buttons.length; i++) { var active = buttons[i].getAttribute('data-filter') === filter; buttons[i].classList.toggle('active', active); buttons[i].setAttribute('aria-pressed', active ? 'true' : 'false'); }
    render();
  }
  function loadInputs() {
    read('/api/inputs', function (inputs) {
      var host = document.getElementById('inputs'); host.textContent = '';
      if (!inputs.length) host.textContent = 'لم يعلن التلفاز مداخل مفعّلة بصيغة مدعومة.';
      inputs.forEach(function (input) { var b = element('button', '', input.name); b.addEventListener('click', function () { command('/api/input', {input: input.id}); }); host.appendChild(b); });
    });
  }
  function loadSettings(group) {
    read('/api/settings/' + group, function (settings) {
      var host = document.getElementById('settings'); host.textContent = '';
      if (!settings.length) host.textContent = 'لا توجد إعدادات مسموحة معلنة بهذه الصيغة. استخدم قائمة التلفاز.';
      settings.forEach(function (setting, i) {
        var row = element('div', 'setting-row'), label = element('label', '', setting.name), id = 'setting-' + group + '-' + i;
        row.appendChild(label);
        if (!setting.spec) { row.appendChild(element('small', '', String(setting.value) + ' · قراءة فقط')); host.appendChild(row); return; }
        var input, spec = setting.spec;
        if (spec.kind === 'enum') {
          input = element('select'); spec.choices.forEach(function (choice) { var option = element('option', '', String(choice)); option.value = JSON.stringify(choice); if (choice === setting.value) option.selected = true; input.appendChild(option); });
        } else {
          input = element('input'); input.type = 'number'; input.min = spec.min; input.max = spec.max; input.step = spec.step; input.value = setting.value;
        }
        input.id = id; label.htmlFor = id; row.appendChild(input);
        var apply = element('button', 'button secondary', 'تطبيق');
        apply.addEventListener('click', function () {
          var value = spec.kind === 'enum' ? JSON.parse(input.value) : Number(input.value);
          if (spec.kind !== 'enum' && (input.value === '' || !isFinite(value) || Math.floor(value) !== value)) { tell('أدخل عددًا صحيحًا صالحًا.', true); return; }
          command('/api/setting', {group: group, name: setting.id, value: value});
        }); row.appendChild(apply); host.appendChild(row);
      });
    });
  }
  function clock() { var date = new Date(); document.getElementById('clock').textContent = ('0' + date.getHours()).slice(-2) + ':' + ('0' + date.getMinutes()).slice(-2); }
  function visibleFocusable() {
    return Array.prototype.slice.call(document.querySelectorAll('a[href],button,input,select,summary')).filter(function (e) { return !e.disabled && e.getClientRects().length && e.offsetWidth && e.offsetHeight; });
  }
  // Geometry-based navigation follows rendered layout on resize and in RTL.
  function moveFocus(key) {
    var all = visibleFocusable(), current = document.activeElement;
    if (!all.length) return;
    if (all.indexOf(current) === -1) { all[0].focus(); return; }
    var r = current.getBoundingClientRect(), x = (r.left + r.right) / 2, y = (r.top + r.bottom) / 2, best = null, score = Infinity;
    all.forEach(function (candidate) {
      if (candidate === current) return;
      var c = candidate.getBoundingClientRect(), dx = (c.left + c.right) / 2 - x, dy = (c.top + c.bottom) / 2 - y;
      var horizontal = key === 'ArrowLeft' || key === 'ArrowRight';
      var forward = key === 'ArrowRight' ? dx : key === 'ArrowLeft' ? -dx : key === 'ArrowDown' ? dy : -dy;
      if (forward < 8) return;
      var lateral = Math.abs(horizontal ? dy : dx), value = forward + lateral * 3;
      if (value < score) { best = candidate; score = value; }
    });
    if (best) { best.focus(); try { best.scrollIntoView({block: 'nearest', inline: 'nearest'}); } catch (e) { best.scrollIntoView(false); } }
  }
  document.addEventListener('keydown', function (event) {
    var legacy = {37: 'ArrowLeft', 38: 'ArrowUp', 39: 'ArrowRight', 40: 'ArrowDown', 13: 'Enter', 27: 'Escape', 461: 'BrowserBack', 10009: 'BrowserBack'};
    var key = event.key; if (!key || key === 'Unidentified') key = legacy[event.keyCode];
    var current = document.activeElement;
    var editing = current && /^(INPUT|SELECT|TEXTAREA)$/.test(current.tagName);
    if (key === 'Escape' || key === 'BrowserBack' || key === 'GoBack') {
      if (current && current.tagName === 'SELECT') return;
      event.preventDefault(); search.value = ''; setFilter('all'); document.querySelector('[data-filter="all"]').focus(); return;
    }
    if (editing && (key === 'ArrowLeft' || key === 'ArrowRight' || current.tagName === 'SELECT' || (current.type === 'number' && (key === 'ArrowUp' || key === 'ArrowDown')))) return;
    if (/^Arrow(Up|Down|Left|Right)$/.test(key)) { event.preventDefault(); moveFocus(key); }
    else if (key === 'Enter' && !editing && current && /^(BUTTON|A)$/.test(current.tagName)) { event.preventDefault(); if (!event.repeat) current.click(); }
    else if (!editing && (key === 'f' || key === 'F')) {
      var node = current; while (node && node !== document.body && !node.getAttribute('data-app-id')) node = node.parentNode;
      if (node && node.getAttribute && node.getAttribute('data-app-id')) { var id = node.getAttribute('data-app-id'); saveFavorite(id); render(id); }
    }
  });
  loadFavorites(); clock(); setInterval(clock, 30000);
  search.addEventListener('input', function () { render(); });
  Array.prototype.forEach.call(document.querySelectorAll('[data-filter]'), function (b) { b.addEventListener('click', function () { setFilter(b.getAttribute('data-filter')); }); });
  document.getElementById('show-favorites').addEventListener('click', function () { setFilter('favorites'); document.getElementById('catalog').scrollIntoView(); document.querySelector('[data-filter="favorites"]').focus(); });
  request('/tv/catalog.json', null, function (error, data) {
    if (error || !data || Object.prototype.toString.call(data.apps) !== '[object Array]') { tell('تعذر تحميل الكتالوج. تحقق من ملفات المشروع.', true); return; }
    apps = data.apps; render(); tell(control ? 'اختر تطبيقًا أو أمرًا من لوحة Mac. جميع التطبيقات الأصلية غير مختبرة على جهازك بعد.' : 'الأسهم للتنقل · OK للاختيار · التطبيقات الأصلية تُشغّل من لوحة Mac.');
  });
  if (control) {
    request('/api/session', null, function (error, data) {
      if (error) { tell(error, true); return; }
      csrf = data.csrf; offline = data.offline;
      document.getElementById('connection').textContent = offline ? 'وضع المعاينة دون تلفاز · لا أوامر حقيقية ولا نتائج جهاز.' : 'جلسة تحكم محلية. اضغط «قراءة حالة الجهاز» للتحقق من الوصول.';
    });
    document.getElementById('refresh').addEventListener('click', function () { read('/api/status', function (data) { document.getElementById('connection').textContent = JSON.stringify(data); }); });
    document.getElementById('conjure').addEventListener('click', function () { command('/api/conjure', {}); });
    document.getElementById('load-inputs').addEventListener('click', loadInputs);
    document.getElementById('check-reachability').addEventListener('click', function () {
      request('/api/diagnostics', null, function (error, data) {
        if (error) { tell(error, true); return; } output(data);
        tell(data.data.tv_page_requested_at_utc ? 'وصل طلب صفحة من عنوان التلفاز المُعدّ. هذا لا يثبت ظهور الواجهة؛ تحقق من الشاشة.' : 'لم يُرصد طلب صفحة من عنوان التلفاز المُعدّ خلال هذه الجلسة. افحص وصول التلفاز إلى Mac.');
      });
    });
    Array.prototype.forEach.call(document.querySelectorAll('[data-key]'), function (b) { b.addEventListener('click', function () { command('/api/key', {key: b.getAttribute('data-key')}); }); });
    Array.prototype.forEach.call(document.querySelectorAll('[data-read]'), function (b) { b.addEventListener('click', function () { read('/api/read/' + b.getAttribute('data-read')); }); });
    Array.prototype.forEach.call(document.querySelectorAll('[data-settings]'), function (b) { b.addEventListener('click', function () { loadSettings(b.getAttribute('data-settings')); }); });
  }
}());
