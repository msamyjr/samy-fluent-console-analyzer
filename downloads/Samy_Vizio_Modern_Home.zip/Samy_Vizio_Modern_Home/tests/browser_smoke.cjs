// Optional developer test: requires Playwright + Chromium, not needed to run the app.
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
(async () => {
  const browser = await chromium.launch({headless:true,executablePath:process.env.SAMY_CHROMIUM_PATH || undefined});
  try {
  const page = await browser.newPage({viewport:{width:1920,height:1080}});
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  await page.goto('http://127.0.0.1:8099/tv/');
  await page.waitForSelector('.app-card');
  assert.equal(await page.locator('.app-card').count(),11);
  await page.screenshot({path:'artifacts/tv-desktop.png',fullPage:true});
  await page.locator('#search').fill('Netflix');
  assert.equal(await page.locator('.app-card').count(),1);
  await page.locator('.favorite').click();
  await page.reload(); await page.waitForSelector('.app-card');
  await page.locator('[data-filter="favorites"]').click();
  assert.equal(await page.locator('.app-card').count(),1);
  assert.match(await page.locator('.app-title').innerText(),/Netflix/);
  await page.locator('.app-launch').click();
  assert.match(await page.locator('#notice').innerText(),/Mac/);
  await page.locator('[data-filter="all"]').click();
  await page.locator('.app-launch').first().focus();
  await page.keyboard.press('ArrowLeft');
  assert.equal(await page.evaluate(()=>document.activeElement.tagName),'BUTTON');
  await page.evaluate(() => document.dispatchEvent(new KeyboardEvent('keydown', {key:'Unidentified',keyCode:40,bubbles:true})));
  assert.equal(await page.evaluate(()=>document.activeElement.tagName),'BUTTON');
  await page.locator('#search').fill('no-such-app');
  assert.equal(await page.locator('.app-card').count(),0);
  await page.keyboard.press('Escape');
  assert.equal(await page.locator('.app-card').count(),11);
  await page.setViewportSize({width:390,height:844});
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
  await page.screenshot({path:'artifacts/tv-mobile.png',fullPage:true});
  await page.setViewportSize({width:1440,height:1000});
  await page.goto('http://127.0.0.1:8766/'); await page.waitForSelector('.app-card');
  await page.waitForFunction(()=>document.querySelector('#connection').textContent.includes('دون تلفاز'));
  await page.locator('[data-key="volume_up"]').click();
  assert.match(await page.locator('#notice').innerText(),/معاينة دون تلفاز/);
  await page.locator('summary').click();
  await page.locator('#check-reachability').click();
  await page.waitForFunction(()=>document.querySelector('#notice').textContent.includes('لم يُرصد'));
  await page.screenshot({path:'artifacts/mac-controller.png',fullPage:true});
  assert.deepEqual(errors,[]);
  console.log('PASS: 11 catalog entries; search; persistent favorites; TV native-action restriction; arrow navigation; Escape; mobile overflow; offline command rejection; diagnostics; no browser exceptions. No real TV used.');
  } finally { await browser.close(); }
})().catch(e=>{console.error(e);process.exitCode=1;});
