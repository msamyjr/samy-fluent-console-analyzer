# Samy TV — English edition

An independent TV-friendly launcher and local Mac dashboard for the owner's Vizio D40f-G9. Python standard library only; no pip packages are needed to run it. The entire application interface, messages, catalog, accessibility labels, and layout are English and left-to-right.

This is a hosted companion, not Google Play, Android TV, replacement firmware, or a permanent TV home screen. The Mac server must remain running. A certified external Google TV device over HDMI is the practical standalone alternative; no internal installation method has been demonstrated for this TV.

## Start on macOS

Unzip `Samy_Vizio_Modern_Home.zip` onto your Desktop:

```bash
cd "$HOME/Desktop/Samy_Vizio_Modern_Home"
python3 --version
python3 -m unittest discover -s tests -v
python3 main.py preview
```

Python 3.13 is the owner's runtime. Python 3.13.5 was tested in Linux; the owner also ran the earlier 40-test release successfully on macOS with Python 3.13.17. The current app suite has 55 offline tests.

Keep Terminal open. In another Terminal window:

```bash
open http://127.0.0.1:8766/
open http://127.0.0.1:8099/tv/
```

`preview` works offline without authentication. If an existing private config is present, it enables local controls but does not automatically launch Conjure. Stop with Control+C.

## Pair using an existing AUTH token

Run on the owner's Mac on the same network as the TV, not from the cloud environment. Never paste tokens into chat or shell arguments.

If you have a certificate fingerprint from a trusted channel:

```bash
python3 main.py setup 192.164.113.114 --certificate-sha256 YOUR_KNOWN_64_HEX_SHA256
```

For a self-signed certificate without a previously trusted fingerprint, explicit first-use trust is available:

```bash
python3 main.py setup 192.164.113.114 --trust-on-first-use
```

Inspect the fingerprint and type uppercase `TRUST` only if you trust the connection to your TV. First-use trust cannot establish identity on hostile Wi-Fi. Enter AUTH in the hidden prompt. The app pins the exact certificate before sending AUTH on later requests; investigate a changed certificate instead of automatically trusting it again.

Setup validates the D40f-G9 model and saves `.vizio_local.json` atomically with permissions 0600. It is ignored by Git and excluded from download bundles. If your token was actually exposed elsewhere, rotate it through your supported pairing flow and rerun setup. The project does not perform pairing rotation itself.

```bash
python3 main.py diagnose
python3 main.py snapshot
python3 main.py launch
```

`launch` starts both servers and sends the hosted URL to Conjure using app ID `17`, namespace `4`, and `MESSAGE=http://MAC_LAN_IP:8099/tv/`. API acceptance is not proof of rendering. Check the physical TV screen and its remote. The dashboard's Diagnostics section can report whether a page request arrived from the configured TV address; that establishes an HTTP request only, not rendering or playback.

## Controls and apps

Use the local Mac dashboard to send native commands. The TV page on LAN is static and read-only; selecting a native app there directs you to the Mac dashboard.

```bash
python3 main.py key volume_up
python3 main.py key volume_down
python3 main.py key mute
python3 main.py app netflix
python3 main.py read current_app
python3 main.py input
python3 main.py read current_input
python3 main.py settings picture
python3 main.py settings audio
```

Only select an input CNAME that the TV actually advertises as enabled. Input switching reads a fresh HASHVAL from the current-input endpoint, not the input-list item. Example, conditional on discovering HDMI-2:

```bash
python3 main.py input HDMI-2
```

Picture and audio writes are restricted to allowlisted ordinary controls, enabled metadata, a valid HASHVAL, and advertised scalar choices or integer ranges. Unknown metadata remains read-only. No calibration, service, system, or network writes are provided. A HASHVAL_ERROR causes one refetch and revalidation only. If brightness 50 is inside an advertised writable range:

```bash
python3 main.py set picture brightness 50
```

App IDs for Netflix, Prime Video, Hulu, Plex, WatchFree, FilmRise, and DAZN are community references, not a discovered list of currently installed or regionally available apps. Website tiles are links, not installed applications. Favorites are stored locally per browser/origin and do not automatically sync from Mac to TV.

## WatchFree+ in Malaysia

The owner is in Malaysia. The bundled legacy WatchFree reference is namespace `2`, app ID `22`. Neither API acceptance nor a matching current app establishes that the current WatchFree+ service or its channels are available there.

```bash
python3 main.py watchfree
python3 main.py watchfree --check
```

The first launches once, then reads the current app. The second is read-only; use it after the TV has had time to start the app. The dashboard also offers Launch WatchFree+ and Check current app.

`matches_legacy_id=true` means the TV reports the legacy identity. `false` means another identity was reported, and `null` means the response shape could not identify the app. `screen_verified` and `playback_verified` remain false because the software does not see the screen. Verify an actual channel picture and audio yourself. No region, entitlement, or DRM bypass is implemented, and network settings are unchanged.

## Spotify and Malaysian websites

Spotify opens `https://open.spotify.com/`; no native Spotify app ID is invented. Audio and DRM support in the old TV browser are unverified. In Spotify on a phone or Mac, check the device picker and select the TV only if it appears as a compatible Spotify Connect receiver. Availability and some features may depend on the device, service, or subscription.

RTM Klik and Astro AWANI are official Malaysian website links. They are not copied streams or native app installations. Website loading and actual TV video playback need separate checks. Cloud requests to these sites and VIZIO support were denied by network policy; that does not establish a failure on the owner's network.

## Troubleshooting

- Keep the server running. The TV must use the Mac LAN URL, not 127.0.0.1.
- An incoming Python connection may need permission in macOS Firewall. Do not disable the entire firewall.
- Open Wi-Fi client isolation may block TV-to-Mac traffic even if Mac-to-TV remote commands work. The project does not change DNS, VPN, region, or network settings, and does not scan the subnet.
- The explicit owner-supplied TV address 192.164.113.114 is not RFC1918 private; the app accepts it as a specific configured host.
- The dashboard is bound only to 127.0.0.1:8766. Port 8099 serves a strict public asset allowlist. Do not forward or expose the dashboard port on LAN.
- The corrected dashboard permits top-level links from other sites while retaining Host, Origin, Fetch Metadata, and CSRF protection for APIs. If an old version shows `Same-origin access required`, type the dashboard address directly or install the update.
- If Conjure cannot render the page, try macOS screen mirroring through AirPlay only if the TV appears as a compatible receiver, or use HDMI. AirPlay compatibility is unverified and still requires a running Mac. TV remote buttons do not automatically become Mac keyboard events.

## Update without pairing again

Stop the server, then run the published `downloads/update.py` from your existing project folder. It verifies the archive SHA-256, rejects unsafe paths and any bundled private config, backs up application files under `backups/`, and does not read or copy `.vizio_local.json`. Updates preserve pairing. Existing Arabic documentation is left in older folders to preserve user files; use this English README for the current release.

## Validation and project files

```bash
python3 -m unittest discover -s tests -v
```

TV HTTPS is mocked in these tests; local HTTP servers are real. Optional developer browser tests require Node, Playwright, and Chromium, which are not application dependencies:

```bash
node tests/browser_smoke.cjs
node tests/browser_controls.cjs
```

In the cloud environment, system Chromium was selected with `SAMY_CHROMIUM_PATH=/usr/bin/chromium`. The controls browser test simulates TV API responses. See `TEST_RESULTS.md`, `COMPATIBILITY.md`, and `REAL_DEVICE_TESTS.md` for evidence and limits. Images in `artifacts/` are local-browser screenshots, not TV photographs.

Runtime files are `main.py` and `site/`. The old repository-root `index.html` is not the app entry point. `CODEX_PROMPT.md` is the historical supplied brief, not evidence of TV compatibility or token exposure. Setup never flashes firmware, resets the TV, changes its network settings, or installs APKs.
